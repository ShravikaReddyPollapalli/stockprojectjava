package com.jfsfeb.stockmanagementsystem.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;


public interface CompanyDAO {
	
		ManagerInfoBean loginManager(String email,String password);
		
		boolean changePassword(long mobileNumber, String password);
		
		boolean addStocks(StockInfoBean stockBean);
		
		boolean updateStockTypeById(int id,String type);
		
		boolean updateStockPriceByName(String name,double price);
		
		boolean updateStockQuantityByType(String type,int quantity);
		
		boolean removeStocks(int id);
		
		List<StockInfoBean> searchStockByName(String productName);
		
		List<StockInfoBean> searchStockByType(String type);
	
		List<StockInfoBean> searchStockByPrice(Double price);
		
		List<StockInfoBean> getStockDetails();		
		
}

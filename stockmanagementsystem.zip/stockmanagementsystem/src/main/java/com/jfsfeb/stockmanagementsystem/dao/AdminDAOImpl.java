package com.jfsfeb.stockmanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;
import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.exception.SMSException;
import com.jfsfeb.stockmanagementsystem.repository.StockRepository;

public class AdminDAOImpl implements AdminDAO {

	@Override
	public boolean registerManager(ManagerInfoBean managerInfoBean) {
		// TODO Auto-generated method stub
		for (ManagerInfoBean manager : StockRepository.manager) {
			if (manager.getEmailId().equals(managerInfoBean.getEmailId())) {
				return false;
			}
		}
		StockRepository.manager.add(managerInfoBean);
		return true;
	}

	@Override
	public boolean updateManager(String mail, long phnum) {
		ManagerInfoBean bean = new ManagerInfoBean();
		boolean updateStatus = false;
		for (int i = 0; i <= StockRepository.manager.size() - 1; i++) {
			ManagerInfoBean retrievedManager = StockRepository.manager.get(i);

			long retrievedNum = retrievedManager.getMobileNumber();
			if (phnum == retrievedNum) {
				StockRepository.manager.remove(i);
				bean.setEmailId(mail);
				bean.setMobileNumber(phnum);
				bean.setId(retrievedManager.getId());
				bean.setName(retrievedManager.getName());
				bean.setPassword(retrievedManager.getPassword());

				updateStatus = true;
				StockRepository.manager.add(bean);
				break;
			}
		}

		return updateStatus;
	}

	@Override
	public boolean removeManager(int id) {
		boolean removeStatus = false;
		for (int i = 0; i <= StockRepository.manager.size() - 1; i++) {
			ManagerInfoBean retrievedManager = StockRepository.manager.get(i);
			int retrievedId = retrievedManager.getId();
			if (id == retrievedId) {
				removeStatus = true;
				StockRepository.manager.remove(i);
				break;
			}
		}
		return removeStatus;
	}

	@Override
	public boolean addCompany(CompanyInfoBean companyInfoBean) {
		for (CompanyInfoBean b : StockRepository.company) {
			if (b.getCompanyId() == companyInfoBean.getCompanyId()) {
				return false;
			}
		}
		StockRepository.company.add(companyInfoBean);
		return true;

	}

	@Override
	public boolean updateCompany(int id, String name) {
		CompanyInfoBean bean6 = new CompanyInfoBean();
		boolean updateStatus = false;
		for (int i = 0; i <= StockRepository.company.size() - 1; i++) {
			CompanyInfoBean retrievedid = StockRepository.company.get(i);
			int retrievedId1 = retrievedid.getCompanyId();
			if (id == retrievedId1) {
				StockRepository.company.remove(i);
				bean6.setCompanyId(id);
				bean6.setCompanyName(name);
				updateStatus = true;
				break;

			}
		}
		StockRepository.company.add(bean6);
		return updateStatus;
	}

	@Override
	public boolean removeCompany(String name) {
		boolean removeStatus = false;
		for (int i = 0; i <= StockRepository.company.size() - 1; i++) {
			CompanyInfoBean removeCompany = StockRepository.company.get(i);
			String retrievedName = removeCompany.getCompanyName();
			if (name.equals(retrievedName)) {
				removeStatus = true;
				StockRepository.company.remove(i);
				break;
			}
		}
		return removeStatus;
	}

	@Override
	public List<CompanyInfoBean> getAllCompanies() {
		List<CompanyInfoBean> usersList1 = new ArrayList<CompanyInfoBean>();
		for (CompanyInfoBean companyBean : StockRepository.company) {

			companyBean.getCompanyId();
			companyBean.getCompanyName();
			usersList1.add(companyBean);

		}
		return usersList1;
	}

	@Override
	public List<ManagerInfoBean> getAllCompanyManagerInfo() {
		List<ManagerInfoBean> usersList1 = new ArrayList<ManagerInfoBean>();
		for (ManagerInfoBean managerBean : StockRepository.manager) {

			managerBean.getId();
			managerBean.getName();
			managerBean.getEmailId();
			managerBean.getPassword();
			managerBean.getMobileNumber();
			usersList1.add(managerBean);

		}
		return usersList1;
	}

	@Override
	public boolean registerAdmin(AdminInfoBean adminInfoBean) {
		for (AdminInfoBean register : StockRepository.admin) {
			if (register.getEmailId().equals(adminInfoBean.getEmailId())) {
				return false;
			}
		}
		StockRepository.admin.add(adminInfoBean);
		return true;
	}

	@Override
	public AdminInfoBean authenticateAdmin(String email, String password) {
		for (AdminInfoBean admin : StockRepository.admin) {
			if ((admin.getEmailId().equals(email)) && (admin.getPassword().equals(password))) {

				return admin;
			}
		}
		throw new SMSException("Invalid credentials");
	}

}

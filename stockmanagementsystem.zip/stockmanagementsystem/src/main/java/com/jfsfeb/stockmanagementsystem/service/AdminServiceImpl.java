package com.jfsfeb.stockmanagementsystem.service;

import java.util.List;
import com.jfsfeb.stockmanagementsystem.dao.AdminDAO;
import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.factory.Factory;
import com.jfsfeb.stockmanagementsystem.validation.Validation;


public class AdminServiceImpl implements AdminService {
	
	private AdminDAO dao=Factory.getAdminDAOImplInstance();
	
	Validation validation = Factory.getValidationInstance();

	
	@Override
	public AdminInfoBean authenticateAdmin(String email, String password) {
		
		if (validation.validatedEmail(email)) {
			if (validation.validatedPassword(password)) {
				return dao.authenticateAdmin(email, password);
			}

		}
		return null;
	}
	
	
	@Override
	public boolean registerManager(ManagerInfoBean managerInfoBean) {
		if (managerInfoBean != null) {
			if (validation.validatedEmail(managerInfoBean.getEmailId())) {
				if (validation.validatedPassword(managerInfoBean.getPassword())) {
					if (validation.validatedName(managerInfoBean.getName())) {
						if (validation.validatedId(managerInfoBean.getId())) {
							if (validation.validatedMobile(managerInfoBean.getMobileNumber()))   {
                                
	                                 return dao.registerManager(managerInfoBean);
                                 
								
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public boolean removeManager(int id) {
		if(id!=0) {
			return dao.removeManager(id);
		}
		return false;
		
	}

	@Override
	public boolean updateManager(String mail, long phnum) {
		if (mail != null && phnum != 0) {
			if (validation.validatedEmail(mail)) {
				if (validation.validatedMobile(phnum)) {

					return dao.updateManager(mail, phnum);
				}
			}
		}
		return false;
	}

	@Override
	public boolean removeCompany(String name) {
		if (name != null) {
			if(validation.validatedName(name)) {
				
			return dao.removeCompany(name);
		} 
			}
		return false;
	}

	@Override
	public boolean updateCompany(int id, String cName ) {
		if (id != 0 && cName != null) {
			if (validation.validatedId(id)) {
				if (validation.validatedName(cName)) {
					return dao.updateCompany(id, cName);
				}
			}
		}
		return false;
	}

	@Override
	public boolean registerAdmin(AdminInfoBean admin) {
		// TODO Auto-generated method stub
		return dao.registerAdmin(admin);
	}

	

	
	@Override
	public List<CompanyInfoBean> getAllCompanies() {
		// TODO Auto-generated method stub
		return dao.getAllCompanies();
	}

	
	@Override
	public boolean addCompany(CompanyInfoBean companyInfoBean) {
		if (companyInfoBean != null) {
			if (validation.validatedId(companyInfoBean.getCompanyId())) {
				if (validation.validatedName(companyInfoBean.getCompanyName())) {

				}

				return dao.addCompany(companyInfoBean);
			}
		}
		return false;
	}

	@Override
	public List<ManagerInfoBean> getAllCompanyManagerInfo() {
		// TODO Auto-generated method stub
		return dao.getAllCompanyManagerInfo();
	}
}

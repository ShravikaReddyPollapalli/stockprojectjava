package com.jfsfeb.stockmanagementsystem.dto;

import lombok.Data;

@Data
public class BuyStockInfoBean {
	
	private StockInfoBean stockInfoBean;
	private UserInfoBean userInfoBean;
	
}

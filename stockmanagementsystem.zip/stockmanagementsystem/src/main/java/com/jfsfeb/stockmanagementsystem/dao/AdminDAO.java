package com.jfsfeb.stockmanagementsystem.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;

public interface AdminDAO {

	boolean registerManager(ManagerInfoBean managerInfoBean);

	boolean updateManager(String emailId, long mobileNumber);

	boolean removeManager(int id);

	List<ManagerInfoBean> getAllCompanyManagerInfo();

	boolean addCompany(CompanyInfoBean companyInfoBean);

	boolean updateCompany(int id, String name);

	boolean removeCompany(String name);

	List<CompanyInfoBean> getAllCompanies();

	boolean registerAdmin(AdminInfoBean adminInfoBean);

	AdminInfoBean authenticateAdmin(String emailId, String password);
}

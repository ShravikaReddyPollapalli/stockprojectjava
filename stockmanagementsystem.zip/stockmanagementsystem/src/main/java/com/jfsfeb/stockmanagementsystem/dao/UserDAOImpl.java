package com.jfsfeb.stockmanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystem.exception.SMSException;
import com.jfsfeb.stockmanagementsystem.repository.StockRepository;

public class UserDAOImpl implements UserDAO {

	

	@Override
	public UserInfoBean loginUser(String email, String password) {
		for(UserInfoBean user : StockRepository.user) {
			if((user.getEmailId().equals(email) ) && (user.getPassword().equals(password))) {
				
					return user;
			}
		}
		throw new SMSException("Invalid credentials");
	}

	@Override
	public boolean changePassword(long regMobile, String regPassword) {
		UserInfoBean bean= new  UserInfoBean();
		boolean updateStatus=false;
	for(int i=0;i<=StockRepository.user.size()-1;i++)
	{
		UserInfoBean retrievedManager=StockRepository.user.get(i);
		
		long retrievedNum=retrievedManager.getMobileNumber();
		if(regMobile==retrievedNum)
		{  
			StockRepository.user.remove(i);
			bean.setPassword(regPassword);
			bean.setMobileNumber(regMobile);
			bean.setUserId(retrievedManager.getUserId());
		    bean.setUserName(retrievedManager.getUserName());
		    bean.setEmailId(retrievedManager.getEmailId());
		   
			updateStatus=true;
		    
			break;
		}
	}
	StockRepository.user.add(bean);
	return updateStatus;
	}

	

	@Override
	public boolean registerUser(UserInfoBean user) {
		for(UserInfoBean u : StockRepository.user) {
			if(u.getEmailId().equals(user.getEmailId())) {
				return false;
			}
		}
		StockRepository.user.add(user);
		return true;
	}

	@Override
	public BuyStockInfoBean buyRequest(UserInfoBean user, StockInfoBean stockBean) {
		boolean flag = false; 
		boolean	isRequestExists = false;
		BuyStockInfoBean requestInfo = new BuyStockInfoBean();
		UserInfoBean userInfo2 = new UserInfoBean();
		StockInfoBean bookInfo2 = new StockInfoBean();

		for (BuyStockInfoBean requestInfo2 : StockRepository.request) {
			if (stockBean.getId() == requestInfo2.getStockInfoBean().getId()) {
				isRequestExists = true;
			}
			}
		if (!isRequestExists) {
			for (UserInfoBean userBean : StockRepository.user) {
				if (user.getUserId() == userBean.getUserId()) {
					for (StockInfoBean stock : StockRepository.stock) {
						if (stock.getId() == stock.getId()) {
							userInfo2 = userBean;
							bookInfo2 = stock;
							flag = true;
						}
					}
				}
			}
			if (flag == true) {
				requestInfo.setStockInfoBean(bookInfo2);
				requestInfo.setUserInfoBean(userInfo2);;
				StockRepository.request.add(requestInfo);
				return requestInfo;
			}

		}
throw new SMSException("invalid ");
//		
		}

	@Override
	public List<StockInfoBean> searchProductByType(String type) {
		List<StockInfoBean> searchList = new ArrayList<StockInfoBean>();
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedStock = StockRepository.stock.get(i);
			String retrievedType = retrievedStock.getType();
			if (type.equals(retrievedType)) {
				searchList.add(retrievedStock);
			}
		}
		if (searchList.size() == 0) {
			throw new SMSException("stock not found");
		} else {
			return searchList;
		}
	}

	@Override
	public List<StockInfoBean> searchProductByName(String name) {
		List<StockInfoBean> searchList = new ArrayList<StockInfoBean>();
		for (int i = 0; i <= StockRepository.stock.size() - 1; i++) {
			StockInfoBean retrievedStock = StockRepository.stock.get(i);
			String retrievedPname = retrievedStock.getProductName();
			if (name.equals(retrievedPname)) {
				searchList.add(retrievedStock);
				return searchList;
			}
		}
		if (searchList.size() == 0) {
			throw new SMSException("Stock not found");
		} else {
			return searchList;
	}
	}

	

	@Override
	public List<StockInfoBean> getAllStockInfo() {
		// TODO Auto-generated method stub
		return StockRepository.stock;
	}

	@Override
	public boolean updateManager(String mail, long mobileNumber) {
		UserInfoBean bean= new UserInfoBean();
		boolean updateStatus=false;
		for(int i=0;i<=StockRepository.user.size()-1;i++)
		{
			UserInfoBean retrievedManager=StockRepository.user.get(i);

			long retrievedNum=retrievedManager.getMobileNumber();
			if(mobileNumber==retrievedNum)
			{  
				StockRepository.user.remove(i);
				bean.setEmailId(mail);
				bean.setMobileNumber(mobileNumber);
				bean.setEmailId(retrievedManager.getEmailId());
				bean.setUserName(retrievedManager.getUserName());
				bean.setPassword(retrievedManager.getPassword());

				updateStatus=true;

				break;
			}
		}
		StockRepository.user.add(bean);
		return updateStatus;

	}

	}


package com.jfsfeb.stockmanagementsystem.service;

import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;


public interface CompanyService {
	
	ManagerInfoBean loginManager(String email,String password);
	
	boolean addStocks(StockInfoBean stockBean);
	
	boolean updateStockTypeById(int id,String type);

	boolean updateStockPriceByName(String name,double price);

	boolean updateStockQuantityByType(String type,int quantity);
	
    List<StockInfoBean> searchStockByName(String productName);

	List<StockInfoBean> searchStockByType(String type);

	List<StockInfoBean> searchStockByPrice(Double price);
	
	boolean changePassword(long mobileNumber, String password);
	
	boolean updateManager(String mail, long phnum);
	
	List<StockInfoBean> getStockDetails();
	
	boolean removeStocks(int id);
}

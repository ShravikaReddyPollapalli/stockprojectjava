package com.jfsfeb.stockmanagementsystem.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystem.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.UserInfoBean;

public interface UserDAO {
	UserInfoBean loginUser(String email,String password);
	
	boolean changePassword(long regMobile, String regPassword);
	
//	List<BuyStockInfoBean> showBuyStock();
	
	boolean registerUser(UserInfoBean user);
	
    BuyStockInfoBean buyRequest(UserInfoBean user, StockInfoBean stockBean);
    
	List<StockInfoBean> searchProductByType(String type);
	
	List<StockInfoBean> searchProductByName(String name);
	
	List<StockInfoBean> getAllStockInfo();
	
	boolean updateManager(String mail, long mobileNumber);
}

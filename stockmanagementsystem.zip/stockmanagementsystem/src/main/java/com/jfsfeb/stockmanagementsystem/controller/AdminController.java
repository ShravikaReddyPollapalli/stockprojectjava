package com.jfsfeb.stockmanagementsystem.controller;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.List;
import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystem.exception.SMSException;
import com.jfsfeb.stockmanagementsystem.factory.Factory;
import com.jfsfeb.stockmanagementsystem.repository.StockRepository;
import com.jfsfeb.stockmanagementsystem.service.AdminService;
import lombok.extern.log4j.Log4j;

@Log4j
public class AdminController {

	public void adminController() {

		StockRepository.addToDataBase();

		
		int regId = 0;
		String regName = null;
		long regMobile = 0;
		String regEmail = null;
		String regPassword = null;
		String loginMail = null;
		String loginPassword = null;
		int companyId = 0;
		String companyName = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		AdminService service = Factory.getAdminServiceImplInstance();

		log.info("----------Welcome--------");
		log.info("------Enter Details For Login-----");
		log.info("Enter Email :");
		loginMail = scanner.next();
		log.info("Enter Password :");
		loginPassword = scanner.next();
		try {
			@SuppressWarnings("unused")
			AdminInfoBean login = service.authenticateAdmin(loginMail, loginPassword);
			log.info("You have logged in successfully");

			do {
				try {
					log.info("-----------------------------------");
					log.info("Enter 1 to add company manager");
					log.info("Enter 2 to update company manager");
					log.info("Enter 3 to remove company manager");
					log.info("Enter 4 to see all company managers");
					log.info("Enter 5 to add company");
					log.info("Enter 6 to update company");
					log.info("Enter 7 to remove company");
					log.info("Enter 8 to see all companies");
					log.info("Enter 9 to Logout");
					log.info("-----------------------------------");

					int choice = scanner.nextInt();

					switch (choice) {

					case 1:

						log.info("Enter ID :");
						regId = scanner.nextInt();
						log.info("Enter Name :");
						regName = scanner.next();
						log.info("Enter Mobile :");
						regMobile = scanner.nextLong();
						log.info("Enter Email :");
						regEmail = scanner.next();
						log.info("Enter Password :");
						regPassword = scanner.next();

						ManagerInfoBean managerBean = new ManagerInfoBean();
						managerBean.setId(regId);
						managerBean.setName(regName);
						managerBean.setMobileNumber(regMobile);
						managerBean.setEmailId(regEmail);
						managerBean.setPassword(regPassword);

						boolean check = service.registerManager(managerBean);
						if (check) {
							log.info("Manager Registered successfully");
						} else {
							log.info("Email already exist");
						}

						break;

					case 2:
						log.info("enter mobile number");
						long number = scanner.nextLong();
						log.info("Enter the  new  mail_id  :");
						String mail = scanner.next();

						if (number == 0) {
							log.info("Enter the Valid phnumber");
						} else {
							ManagerInfoBean managerBean1 = new ManagerInfoBean();
							managerBean1.setMobileNumber(number);
							managerBean1.setEmailId(mail);
							boolean update = service.updateManager(mail, number);
							if (update) {
								log.info("company manager updated succesfully");
							} else {
								log.error("company manager is not updated");
							}
						}

						break;

					case 3:

						log.info("Enter the  manager Id to remove :");
						int managerId = scanner.nextInt();
						if (managerId == 0) {
							log.info("Enter the Valid manager Id");
						} else {
							ManagerInfoBean managerBean2 = new ManagerInfoBean();
							managerBean2.setId(managerId);
							boolean remove = service.removeManager(managerId);
							if (remove) {
								log.error("company manager removed succesfully");
							} else {
								log.error("company manager is not removed");
							}
						}

						break;

					case 4:
						List<ManagerInfoBean> info2 = service.getAllCompanyManagerInfo();
						log.info(
								String.format("%-5s %-20s %-20s %-20s %s", "Id", "Name", "number", "mail", "password"));
						for (ManagerInfoBean managerBean3 : info2) {

							if (managerBean3 != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", managerBean3.getId(),
										managerBean3.getName(), managerBean3.getMobileNumber(),
										managerBean3.getEmailId(), managerBean3.getPassword()));

							} else {
								log.info("no managers are available");
							}
						}

						break;

					case 5:
						log.info("Enter company id :");
						companyId = scanner.nextInt();
						log.info("Enter company name :");
						companyName = scanner.next();
						CompanyInfoBean bean = new CompanyInfoBean();
						bean.setCompanyName(companyName);
						bean.setCompanyId(companyId);
						boolean check2 = service.addCompany(bean);
						if (check2) {
							log.info("company added succefully");
							log.info(String.format("%-5s", bean.getCompanyName()));
						} else {
							log.info("company  already exist");
						}

						break;

					case 6:
						log.info("enter new company Id");
						int companyId1 = scanner.nextInt();
						log.info("Enter the  company Name :");
						String companyName1 = scanner.next();

						if (companyName1 == null) {
							log.info("Enter the Valid companyName");
						} else {
							CompanyInfoBean companyBean = new CompanyInfoBean();
							companyBean.setCompanyId(companyId1);
							companyBean.setCompanyName(companyName1);
							boolean update = service.updateCompany(companyId1, companyName1);
							if (update) {
								log.info("company updated succesfully");
							} else {
								log.error("company is not updated");
							}
						}

						break;

					case 7:

						log.info("Enter the company name to remove :");

						companyName = scanner.next();

						if (companyName == null) {
							log.info("Enter the Valid company_name");
						} else {
							CompanyInfoBean companyBean = new CompanyInfoBean();
							companyBean.setCompanyName(companyName);
							boolean remove = service.removeCompany(companyName);
							if (remove) {
								log.error("company removed succesfully");
							} else {
								log.error("company is not removed");
							}
						}

						break;

					case 8:

						List<CompanyInfoBean> info3 = service.getAllCompanies();
						log.info(String.format("%-5s %-20s", "company-Id", "company_name"));
						for (CompanyInfoBean companyBean : info3) {

							if (companyBean != null) {
								log.info(String.format("%-5s %-20s", companyBean.getCompanyId(),
										companyBean.getCompanyName()));

							} else {
								log.info("company info is not present");
							}
						}

						break;
					case 9:
						adminController();
						break;
					default:
						log.error("please enter valid choice between 1-9");
					}

				} catch (InputMismatchException e) {
					log.error("should contain only digits");
					scanner.next();
					
				}
			} while (true);

		} catch (SMSException e) {
			log.error(e.getMessage());

		}

	}

}

package com.jfsfeb.stockmanagementsystem.exception;

@SuppressWarnings("serial")
	public class SMSException extends RuntimeException {
		public SMSException(String msg) {
				
				super(msg);
				
			}
}

package com.jfsfeb.stockmanagementsystem.controller;

import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.jfsfeb.stockmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystem.factory.Factory;
import com.jfsfeb.stockmanagementsystem.repository.StockRepository;
import com.jfsfeb.stockmanagementsystem.service.UserService;
import lombok.extern.log4j.Log4j;

@Log4j
public class InvestorController {
	public void investorController() {
		
		

		int regId = 0;
		String regName = null;
		long regMobile = 0;
		String regEmail = null;
		String regPassword = null;

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		UserService service =Factory.getUserServiceImpl();

		try {
			do {
				try {
					log.info("-----------------------------------");
					log.info("Press 1 to Investor Register");
					log.info("Press 2 to Investor Login");
					log.info("Press 3 to Exit");
					log.info("-----------------------------------");
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:

						log.info("Enter ID :");
						regId = scanner.nextInt();
						log.info("Enter Name :");
						regName = scanner.next();
						log.info("Enter Mobile :");
						regMobile = scanner.nextLong();
						log.info("Enter Email :");
						regEmail = scanner.next();
						log.info("Enter Password :");
						regPassword = scanner.next();

						UserInfoBean bean1 = new UserInfoBean();
						bean1.setUserId(regId);
						bean1.setUserName(regName);
						bean1.setMobileNumber(regMobile);
						bean1.setEmailId(regEmail);
						bean1.setPassword(regPassword);
						boolean check = service.registerUser(bean1);
						if (check) {
							log.info("Registered");
						} else {
							log.info("Email already exist");
						}
						break;

					case 2:

						log.info("Enter Email :");
						regEmail = scanner.next();
						log.info("Enter Password :");
						regPassword = scanner.next();
						try {
							@SuppressWarnings("unused")
							UserInfoBean login = service.loginUser(regEmail, regPassword);
							log.info("Logged in Successfully");
							do {
								try {
									log.info("--------------------------------------------");
									log.info("Press 1 To Change Password");
									log.info("Press 2 To Update EmailId");
									log.info("Press 3 To Search The Stock By Product Name");
									log.info("Press 4 To Search The Stock By Category Or Type");
									log.info("Press 5 To Get Stock Details");
									log.info("Press 6 To Buy Stock");
									log.info("Press 7 To Logout");
									log.info("--------------------------------------------");

									int choice2 = scanner.nextInt();
									switch (choice2) {

									case 1:

										log.info("Enter Mobile :");
										regMobile = scanner.nextLong();
										log.info("Enter New Password :");
										regPassword = scanner.next();
										if (regMobile == 0) {
											log.info("Enter the Valid Mobile Number");
										} else {
											Random random = new Random();
											int otp = random.nextInt(10000);
											log.info(otp < 0 ? otp * -1 : otp);
											log.info("Provide OTP Here");
											int typeOtp = scanner.nextInt();
											if (otp == typeOtp) {

												AdminInfoBean bean = new AdminInfoBean();
												bean.setMobileNumber(regMobile);
												bean.setPassword(regPassword);
												boolean update = service.changePassword(regMobile, regPassword);
												if (update) {
													log.info("password updated succesfully");
												} else {
													log.error("password is not updated");
												}
											} else {
												log.error("otp mismatched");
											}
										}

										break;

									case 2:

										log.info("Enter Mobile Number");
										long number = scanner.nextLong();
										log.info("Enter New EmailId ");
										String mail = scanner.next();
										if (number == 0) {
											log.info("Enter Valid Mobile Number");
										} else {
											UserInfoBean bean = new UserInfoBean();
											bean.setMobileNumber(number);
											bean.setEmailId(mail);
											boolean update = service.updateManager(mail, number);
											if (update) {
												log.info("profile updated succesfully");
											} else {
												log.error("profile is not updated");
											}
										}
										break;

									case 3:
										log.info("Search The Stock By Product Name");
										log.info("enter name");
										String name = scanner.next();
										List<StockInfoBean> company = service.searchProductByName(name);
										log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Product Name",
												"Type", "Price", "Quantity"));
										for (StockInfoBean bean2 : company) {

											if (bean2 != null) {
												log.info(String.format("%-5s %-20s %-20s %-20s %s", bean2.getId(),
														bean2.getProductName(), bean2.getType(), bean2.getPrice(),
														bean2.getQuantity()));
											} else {
												log.info("No stock are available with this product name");
											}
										}
										break;

									case 4:
										log.info("Search the product by type :");
										String type = scanner.next();
										List<StockInfoBean> beanType = service.searchProductByType(type);
										log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Product Name",
												"Type", "Price", "Quantity"));
										for (StockInfoBean bean : beanType) {
											if (bean != null) {
												log.info(String.format("%-5s %-20s %-20s %-20s %s", bean.getId(),
														bean.getProductName(), bean.getType(), bean.getPrice(),
														bean.getQuantity()));
											} else {
												log.info("No stocks are available with this type.");
											}
										}
										break;

									case 5:
										List<StockInfoBean> info = service.getAllStockInfo();
										log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Product Name",
												"Type", "Price", "Quantity"));
										for (StockInfoBean bean : info) {

											if (bean != null) {
												log.info(String.format("%-5s %-20s %-20s %-20s %s", bean.getId(),
														bean.getProductName(), bean.getType(), bean.getPrice(),
														bean.getQuantity()));
											} else {
												log.info("product information  is not present");
											}
										}
										break;

									case 6:
										log.info("Enter stock id");
										int bId = scanner.nextInt();
										StockInfoBean StockInfoBean = new StockInfoBean();
										StockInfoBean.setId(bId);
										log.info("Enter user id");
										int userId = scanner.nextInt();
										UserInfoBean UserInfoBean = new UserInfoBean();
										UserInfoBean.setUserId(userId);

										try {
											BuyStockInfoBean request = service.buyRequest(UserInfoBean, StockInfoBean);
											log.info("Request sent to admin");
											log.info(String.format("%-5s %-20s %-20s %-20s ", "UserName", "ProductName",
													"UserId", "StockId"));
											log.info(String.format("%-10s %-15s %-10s %s",
													request.getUserInfoBean().getUserName(),
												    request.getStockInfoBean().getProductName(),
													request.getUserInfoBean().getUserId(),
													request.getStockInfoBean().getId()));
													
										} catch (Exception e) {

											log.info("Enter valid data");
										}
										break;

									case 7:
										investorController();
										break;

									default:
										log.error("please enter valid choice between 1-7");
										break;
									}

								} catch (Exception e) {

									log.info("stock not found");
								}
							} while (true);

						} catch (Exception e) {
							log.error("invalid credentials ..please try again!!");
						}
						break;

					case 3:
						investorController();
						break;
					default:
						log.error("please enter choice betweem 1-3");

					}
				} catch (Exception e) {
					log.info("should contain only digits");
					investorController();
				}

			} while (true);
		} catch (Exception e) {
			log.error("invalid data,please try again");
			investorController();
		}

	}

}

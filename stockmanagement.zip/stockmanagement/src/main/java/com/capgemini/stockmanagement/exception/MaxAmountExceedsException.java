package com.capgemini.stockmanagement.exception;

@SuppressWarnings("serial")
public class MaxAmountExceedsException extends RuntimeException {

	String message;

	public MaxAmountExceedsException(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}

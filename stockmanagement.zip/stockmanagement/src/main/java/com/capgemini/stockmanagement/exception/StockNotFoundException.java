package com.capgemini.stockmanagement.exception;

@SuppressWarnings("serial")
public class StockNotFoundException extends RuntimeException {
	String message;

	public StockNotFoundException(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
package com.capgemini.stockmanagement.dao;

import java.util.List;

import com.capgemini.stockmanagement.dto.InvestorRequestObject;
import com.capgemini.stockmanagement.dto.InvestorShare;

public interface InvestorDAO {
	boolean addShare(InvestorRequestObject investor);
	boolean buyShare(InvestorRequestObject investor);
	boolean updateStockAvailability(InvestorRequestObject investor, boolean flag);
	public List<InvestorShare> getAllShares(int id);
}

package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;

@SuppressWarnings("unused")
public class CompanyDAOImpl implements CompanyDAO {

	@Override
	public ManagerInfoBean managerLogin(String email, String password) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "select m from ManagerInfoBean m where m.emailId=:emailId and m.password=:password and role='manager'";
			TypedQuery<ManagerInfoBean> query = entityManager.createQuery(jpql, ManagerInfoBean.class);
			query.setParameter("emailId", email);
			query.setParameter("password", password);
			ManagerInfoBean bean = query.getSingleResult();
			return bean;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		} finally {
			entityManager.close();
			entityManagerFactory.close();
		}
	}

	@Override
	public boolean modifyPassword(long mobileNumber, String password) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "update ManagerInfoBean m set m.password=:password1  where m.mobileNumber=:mobileNumber1";
			TypedQuery<ManagerInfoBean> query = entityManager.createQuery(jpql, ManagerInfoBean.class);
			query.setParameter("password1", password);
			query.setParameter("mobileNumber1", mobileNumber);
			ManagerInfoBean bean = query.getSingleResult();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			entityManager.close();
			entityManagerFactory.close();
		}
	}

	@Override
	public boolean insertStocks(StockInfoBean stockBean) {
		StockInfoBean bean = new StockInfoBean();
		bean.setId(stockBean.getId());
		bean.setProductName(stockBean.getProductName());
		bean.setType(stockBean.getType());
		bean.setPrice(stockBean.getPrice());
		bean.setQuantity(stockBean.getQuantity());

		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.persist(bean);
			System.out.println("record is saved");
			entityTransaction.commit();
			return true;

		} catch (Exception e) {
			entityTransaction.rollback();
		}

		entityManager.close();
		entityManagerFactory.close();
		return false;
	}

	@Override
	public boolean modifyStockNameUsingId(int id, String productName) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    StockInfoBean update =entityManager.find(StockInfoBean.class,id);
		update.setProductName(productName);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;
	}

	@Override
	public boolean removeStocks(int id) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();

			StockInfoBean bean = entityManager.find(StockInfoBean.class, id);
			int testId = bean.getId();
			if (testId != 0) {
				entityManager.remove(bean);
				System.out.println("deleted succefully");
				entityTransaction.commit();
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();
		entityManagerFactory.close();
		return false;
	}

	@Override
	public List<StockInfoBean> viewStockUsingName(String productName) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			String jpql = "select s from StockInfoBean s where s.productName=:name";
			TypedQuery<StockInfoBean> query = entityManager.createQuery(jpql, StockInfoBean.class);
			query.setParameter("name", productName);
			List<StockInfoBean> recordList = query.getResultList();
			return recordList;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		} finally {
			entityManager.close();
			entityManagerFactory.close();
		}
	}

	@Override
	public List<StockInfoBean> viewStockDetails() {
		StockInfoBean bean = new StockInfoBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager();
		String jpql = "select s from StockInfoBean s ";

		Query query = manager.createQuery(jpql);
		List<StockInfoBean> recordList = query.getResultList();
		if (recordList != null) {
			for (StockInfoBean objects : recordList) {
				bean.setId(objects.getId());
				bean.setProductName(objects.getProductName());
				bean.setType(objects.getType());
				bean.setPrice(objects.getPrice());
				bean.setQuantity(objects.getQuantity());
				recordList.add(bean);
				return recordList;
			}
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}
}

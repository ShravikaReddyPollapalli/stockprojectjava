package com.jfsfeb.stockmanagementsystemjpawithhibernate.controller;

import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.Factory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.UserService;

import lombok.extern.log4j.Log4j;

@Log4j
public class InvestorController {
	public void investorController() {

		int regId = 0;
		String regName = null;
		long regMobile = 0;
		String regEmail = null;
		String regPassword = null;
		String regRole = null;
		double price=0;
		BuyStockInfoBean buyStockBean = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		UserService service = Factory.getUserServiceImpl();

		try {
			do {
				try {
					log.info("======================================");
					log.info("Enter [1] To Investor Register");
					log.info("Enter [2] To Investor Login");
					log.info("Enter [3] To Exit");
					log.info("=========================================");
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:

						log.info("Enter ID :");
						regId = scanner.nextInt();
						log.info("Enter Name :");
						regName = scanner.next();
						log.info("Enter Mobile :");
						regMobile = scanner.nextLong();
						log.info("Enter Email :");
						regEmail = scanner.next();
						log.info("Enter Password :");
						regPassword = scanner.next();
						log.info("Enter Role: ");
						regRole = scanner.next();

						UserInfoBean bean1 = new UserInfoBean();
						bean1.setUserId(regId);
						bean1.setUserName(regName);
						bean1.setMobileNumber(regMobile);
						bean1.setEmailId(regEmail);
						bean1.setPassword(regPassword);
						bean1.setRole(regRole);
						boolean check = service.userRegistration(bean1);
						if (check) {
							log.info("Registered");
						} else {
							log.info("Email already exist");
						}
						break;

					case 2:

						log.info("Enter Email :");
						regEmail = scanner.next();
						log.info("Enter Password :");
						regPassword = scanner.next();
						try {
							@SuppressWarnings("unused")
							UserInfoBean login = service.userLogin(regEmail, regPassword);
							log.info("Logged in Successfully");
							do {
								try {
									log.info("=============================================");
									log.info("Enter [1] To Change Password");
									log.info("Enter [2] To Get Stock Details");
									log.info("Enter [3] To Buy Stock");
									log.info("Enter [4] To Logout");
									log.info("=================================================");

									int choice2 = scanner.nextInt();
									switch (choice2) {

									case 1:

										System.out.println("Enter Mobile :");
										regMobile = scanner.nextLong();
										System.out.println("Enter new  Password :");
										regPassword = scanner.next();

										if (regMobile == 0) {
											System.out.println("Enter the Valid mobilenumber");
										} else {

											Random random = new Random();
											int otp = random.nextInt(9999);
											System.out.println(otp < 0 ? otp * -1 : otp);
											System.out.println("please ,enter otp ");
											int typeOtp = scanner.nextInt();
											if (otp == typeOtp) {

												UserInfoBean bean6 = new UserInfoBean();
												bean6.setMobileNumber(regMobile);
												bean6.setPassword(regPassword);
												boolean update = service.modifyPassword(regMobile, regPassword);
												if (update) {
													System.out.println("password updated succesfully");
												} else {
													System.err.println("password is not updated");
												}
											} else {
												System.err.println("otp mismatched");
											}
										}
										break;

									case 2:
										List<StockInfoBean> info = service.viewStockDetails();
										log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Product", "Type",
												"Price", "Quantity"));
										for (StockInfoBean StockInfoBean : info) {

											if (StockInfoBean != null) {
												log.info(String.format("%-5s %-20s %-20s %-20s %s",
														StockInfoBean.getId(), StockInfoBean.getProductName(),
														StockInfoBean.getType(), StockInfoBean.getPrice(),
														StockInfoBean.getQuantity()));

											} else {
												log.info("No Stocks Available");
											}
										}
										break;

									case 3:

										System.out.println("Enter stock id");
										int bId = scanner.nextInt();
										StockInfoBean stockBean = new StockInfoBean();
										stockBean.setId(bId);

										System.out.println("Enter user id");
										int userId = scanner.nextInt();
										UserInfoBean userBean = new UserInfoBean();
										userBean.setUserId(userId);

										System.out.println("enter no of products to buy");
										int count = scanner.nextInt();
										stockBean.setQuantity(count);

										System.out.println("enter amount of investment");
										double count1 = scanner.nextInt();
										stockBean.setPrice(price);
										BuyStockInfoBean buyBean = new BuyStockInfoBean();

										try {

											BuyStockInfoBean request = service.showBuyStock(userBean, stockBean,
													buyStockBean);

											System.out.println(" information of buy stock");
											System.out.println(String.format("%-5s %-20s %-20s %-20s %-20s %-20s %s",
													"ProductId", "productName", "type", "Price", "quantity", "user-id",
													"user-name"));

											if (request != null) {

												System.out.println(String.format(
														"%-5s %-20s %-20s %-20s %-20s %-20s %s", request.getId(),
														request.getProductName(), request.getType(), request.getPrice(),
														request.getQuantity(), request.getUserId(),
														request.getUserName()));

											} else {
												System.err.println("product not available");
											}
										} catch (Exception e) {

											System.out.println("product is not available with this id !!");
										}
										break;

									case 4:
										investorController();
										break;

									default:
										System.err.println("please enter valid choice between 1-7");
										break;
									}

								} catch (Exception e) {

									log.info("stock not found");
								}
							} while (true);

						} catch (Exception e) {
							System.err.println("invalid credentials ..please try again!!");
						}
						break;

					case 3:
						investorController();
						break;
					default:
						System.err.println("please enter choice betweem 1-3");

					}
				} catch (Exception e) {
					log.info("should contain only digits");
					investorController();
				}

			} while (true);
		} catch (Exception e) {
			System.err.println("invalid data,please try again");
			investorController();
		}

	}

}

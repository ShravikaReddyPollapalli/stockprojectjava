package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;


import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserInfoBean;

public interface UserDAO {
	boolean userRegistration(UserInfoBean user);

	UserInfoBean userLogin(String email, String password);

	boolean modifyPassword(long mobileNumber, String password);

	BuyStockInfoBean showBuyStock(UserInfoBean userBean,StockInfoBean stockBean,BuyStockInfoBean buyStockBean);

	List<StockInfoBean> viewStockDetails();

}

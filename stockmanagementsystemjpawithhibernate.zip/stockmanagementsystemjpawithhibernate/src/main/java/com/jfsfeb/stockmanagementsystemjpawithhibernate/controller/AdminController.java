package com.jfsfeb.stockmanagementsystemjpawithhibernate.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.Factory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.AdminService;

import lombok.extern.log4j.Log4j;

@Log4j
public class AdminController {
	public void adminController() {

		int userId = 0;
		String userName = null;
		String emailId = null;
		String password = null;
		long mobileNumber = 0;
		String role = null;
		String loginMail = null;
		String loginPassword = null;
		int companyId = 0;
		String companyName = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		AdminService service = Factory.getAdminServiceImplInstance();

		log.info("----------Welcome--------");
		log.info("------Enter Details For Login-----");
		log.info("Enter Email :");
		loginMail = scanner.next();
		log.info("Enter Password :");
		loginPassword = scanner.next();
		try {
			@SuppressWarnings("unused")
			AdminInfoBean login = service.authenticateAdmin(loginMail, loginPassword);

			log.info("You have logged in successfully");
			log.info(" ");
			do {
				try {
					log.info("======================================");
					log.info("Enter [1] to add company manager");
					log.info("Enter [2] to update company manager");
					log.info("Enter [3] to remove company manager");
					log.info("Enter [4] to view company managers");
					log.info("Enter [5] to add company");
					log.info("Enter [6] to update company");
					log.info("Enter [7] to remove company");
					log.info("Enter [8] to view companies");
					log.info("Enter [9] to Logout");
					log.info("========================================");

					int choice = scanner.nextInt();

					switch (choice) {

					case 1:

						log.info("Enter ID :");
						userId = scanner.nextInt();
						log.info("Enter Name :");
						userName = scanner.next();
						log.info("Enter Mobile :");
						mobileNumber = scanner.nextLong();
						log.info("Enter Email :");
						emailId = scanner.next();
						log.info("Enter Password :");
						password = scanner.next();
						log.info("Enter Role :");
						role = scanner.next();
						ManagerInfoBean managerBean = new ManagerInfoBean();
						managerBean.setUserId(userId);
						managerBean.setUserName(userName);

						managerBean.setEmailId(emailId);
						managerBean.setPassword(password);
						managerBean.setMobileNumber(mobileNumber);
						managerBean.setRole(role);
						boolean check = service.managerRegistration(managerBean);
						if (check) {
							log.info("Manager Registered successfully");
						} else {
							log.info("Email already exist");
						}

						break;

					case 2:
						log.info("enter id");
						userId = scanner.nextInt();
						log.info("Enter the  new  mail_id  :");
						String mail = scanner.next();
						ManagerInfoBean managerBean1 = new ManagerInfoBean();
						managerBean1.setUserId(userId);
						managerBean1.setEmailId(mail);
						if (userId == 0) {
							log.info("Enter the valid Id");
						} else {

							boolean update = service.modifyManager(mail, userId);
							if (update) {
								log.info("company manager updated succesfully");
							} else {
								log.info("company manager is not updated");
							}
						}

						break;

					case 3:

						log.info("Enter the  manager Id to remove :");
						int managerId = scanner.nextInt();
						if (managerId == 0) {
							log.info("Enter the Valid manager Id");
						} else {
							ManagerInfoBean managerBean2 = new ManagerInfoBean();
							managerBean2.setUserId(managerId);
							boolean remove = service.deleteManager(managerId);
							if (remove) {
								log.info("company manager removed succesfully");
							} else {
								log.info("company manager is not removed");
							}
						}

						break;

					case 4:
						List<ManagerInfoBean> info2 = service.viewManagerDetails();
						log.info(
								String.format("%-5s %-20s %-20s %-20s %s", "Id", "Name", "number", "mail", "password"));
						for (ManagerInfoBean managerBean3 : info2) {

							if (managerBean3 != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", managerBean3.getUserId(),
										managerBean3.getUserName(), managerBean3.getMobileNumber(),
										managerBean3.getEmailId(), managerBean3.getPassword()));

							} else {
								log.info("no managers are available");
							}
						}

						break;

					case 5:
						log.info("Enter company id :");
						companyId = scanner.nextInt();
						log.info("Enter company name :");
						companyName = scanner.next();
						CompanyInfoBean bean = new CompanyInfoBean();
						bean.setCompanyId(companyId);
						bean.setCompanyName(companyName);
						boolean check2 = service.insertCompany(bean);

						if (check2) {
							log.info("added successfully");
							log.info(String.format("%-5s  %s", bean.getCompanyId(), bean.getCompanyName()));
						} else {
							log.info("already exists!!");
						}

						break;

					case 6:
						log.info("enter new company Id");
						int companyId1 = scanner.nextInt();
						log.info("Enter the  company Name :");
						String companyName1 = scanner.next();

						if (companyName1 == null) {
							log.info("Enter the Valid companyName");
						} else {
							CompanyInfoBean companyBean = new CompanyInfoBean();
							companyBean.setCompanyId(companyId1);
							companyBean.setCompanyName(companyName1);
							boolean update = service.modifyCompany(companyId1, companyName1);
							if (update) {
								log.info("company updated succesfully");
							} else {
								log.info("company is not updated");
							}
						}

						break;

					case 7:

						log.info("Enter the company name to remove :");

						companyName = scanner.next();

						if (companyName == null) {
							log.info("Enter the Valid company_name");
						} else {
							CompanyInfoBean companyBean = new CompanyInfoBean();
							companyBean.setCompanyName(companyName);
							boolean remove = service.deleteCompany(userId, companyName);
							if (remove) {
								log.info("company removed succesfully");
							} else {
								log.info("company is not removed");
							}
						}

						break;

					case 8:

						List<CompanyInfoBean> info3 = service.viewCompanyDetails();
						log.info(String.format("%-5s %-20s", "company-Id", "company_name"));
						for (CompanyInfoBean companyBean : info3) {

							if (companyBean != null) {
								log.info(String.format("%-5s %-20s", companyBean.getCompanyId(),
										companyBean.getCompanyName()));

							} else {
								log.info("company info is not present");
							}
						}

						break;
					case 9:
						adminController();
						break;
					default:
						log.info("please enter valid choice between 1-9");
					}

				} catch (InputMismatchException e) {
					log.info("should contain only digits");
//					scanner.next();
					adminController();
				}
			} while (true);
		} catch (SMSException e) {
			log.info(e.getMessage());
		}

	}
}

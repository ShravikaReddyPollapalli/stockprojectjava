package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.CompanyDAO;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.Factory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.validation.Validation;

public class CompanyServiceImpl  implements CompanyService{

	CompanyDAO dao = Factory.getCompanyDAOImplInstance();

	Validation validation = Factory.getValidationInstance();
	
	@Override
	public ManagerInfoBean managerLogin(String email, String password) {
		if(email!=null && password !=null) {
			if(validation.validatedEmail(email)) {
				if(validation.validatedPassword(password)) {
					return dao.managerLogin(email, password);
				}
			}

		}
		return null;
	}

	@Override
	public boolean insertStocks(StockInfoBean stockBean) {
		if(stockBean != null) {
			if(validation.validatedId(stockBean.getId())) {
				if(validation.validatedName(stockBean.getProductName())) {
					if(validation.validatedName(stockBean.getType())) {
						if(validation.validatedId(stockBean.getQuantity())) {
			                return dao.insertStocks(stockBean);
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public boolean modifyStockNameUsingId(int id, String productName) {
		if(id!=0 && productName != null) {
			if(validation.validatedId(id)) {
				if(validation.validatedName(productName)) {
					return dao.modifyStockNameUsingId(id, productName);
				}
			}
		}
		return false;
	}

	

	@Override
	public List<StockInfoBean> viewStockUsingName(String productName) {
		if(productName != null) {
	    	if(validation.validatedName(productName)) {
		           return dao.viewStockUsingName(productName);
	    	}
	    }
		return null;
	}

	

	@Override
	public boolean modifyPassword(long mobileNumber, String password) {
		if(mobileNumber !=0 && password!=null) {
			if(validation.validatedMobile(mobileNumber)) {
				if(validation.validatedPassword(password)) {
					return dao.modifyPassword(mobileNumber, password);
				}
			}
		}
		return false;
	}

	

	@Override
	public List<StockInfoBean> viewStockDetails() {
		// TODO Auto-generated method stub
		return dao.viewStockDetails();
	}

	@Override
	public boolean removeStocks(int id) {
		if(id !=0) {
			if(validation.validatedId(id)) {
			return dao.removeStocks(id);
			}
		}
		return false;
	}


}

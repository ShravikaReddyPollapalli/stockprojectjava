package com.jfsfeb.stockmanagementsystemjpawithhibernate.factory;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDAO;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDAOImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.CompanyDAO;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.CompanyDAOImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.UserDAO;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.UserDAOImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.AdminService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.AdminServiceImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyServiceImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.UserService;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.UserServiceImpl;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.validation.Validation;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.validation.ValidationImpl;

public class Factory {
	private Factory() {

	}

	public static AdminDAO getAdminDAOImplInstance() {
		AdminDAO dao = new AdminDAOImpl();
		return dao;
	}

	public static UserDAO getUserDAOImplInstance() {
		UserDAO userDao = new UserDAOImpl();
		return userDao;
	}

	public static CompanyDAO getCompanyDAOImplInstance() {
		CompanyDAO companyDao = new CompanyDAOImpl();
		return companyDao;
	}

	public static AdminService getAdminServiceImplInstance() {
		AdminService adminService = new AdminServiceImpl();
		return adminService;
	}

	public static CompanyService getCompanyServiceImplInstance() {
		CompanyService companyService = new CompanyServiceImpl();
		return companyService;
	}

	public static UserService getUserServiceImpl() {
		UserService userService = new UserServiceImpl();
		return userService;
	}
	
	public static Validation getValidationInstance() {
		Validation validation = new ValidationImpl();
		return validation;
	}
}

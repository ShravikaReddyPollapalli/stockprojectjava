package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;


import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserInfoBean;

public class UserDAOImpl implements UserDAO {

	@Override
	public UserInfoBean userLogin(String email, String password) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		String jpql="select u from UserInfoBean u where u.emailId=:email and u.password=:password and role='investor'";
		TypedQuery<UserInfoBean> query = entityManager.createQuery(jpql,UserInfoBean.class);
		query.setParameter("emailId", email);
		query.setParameter("password", password);
		UserInfoBean bean = query.getSingleResult();
		return bean;
	  }catch(Exception e){
		System.err.println(e.getMessage());
		return null;
	  }finally {
		entityManager.close();
		entityManagerFactory.close();
	  }
	}

	@Override
	public boolean modifyPassword(long mobileNumber, String password) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		 manager = entityManagerFactory.createEntityManager();
		 transaction = manager.getTransaction();
		 transaction.begin();
		String jpql = "update UserInfoBean u set u.password=:password  where u.mobileNumber=:mobileNumber ";
		Query query = manager.createQuery(jpql);
		query.setParameter("password",password);
		query.setParameter("mobileNumber", mobileNumber);
		int record = query.executeUpdate();
		System.out.println("Record Update --" +record);
		transaction.commit();
		return true;
		} catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		manager.close();
		entityManagerFactory.close();
		return false;
	}

	@Override
	public boolean userRegistration(UserInfoBean user) {

		   UserInfoBean bean = new UserInfoBean();
			bean.setUserId(user.getUserId());
			bean.setUserName(user.getUserName());
			bean.setMobileNumber(user.getMobileNumber());
			bean.setEmailId(user.getEmailId());
			bean.setPassword(user.getPassword());
			bean.setRole(user.getRole());
			
			EntityManagerFactory entityManagerFactory= null;
			EntityManager entityManager= null;
			EntityTransaction entityTransaction= null;
			try {
				entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
				entityManager = entityManagerFactory.createEntityManager();
				entityTransaction = entityManager.getTransaction();
				entityTransaction.begin();
				entityManager.persist(bean);
				entityTransaction.commit();
				System.out.println("record saved");
					return true;

			}catch(Exception e) {
				entityTransaction.rollback();
			} 
			
			entityManager.close();
			entityManagerFactory.close();
			return false;	
	}

	

	
	

	@Override
	public List<StockInfoBean> viewStockDetails() {
		StockInfoBean bean= new StockInfoBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select s from StockInfoBean s ";
		
		Query query = manager.createQuery(jpql);
		List<StockInfoBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(StockInfoBean objects : recordList ) {

				bean.setId(objects.getId());
				bean.setProductName(objects.getProductName());
				bean.setType(objects.getType());
				bean.setPrice(objects.getPrice());
				bean.setQuantity(objects.getQuantity());
			    recordList.add(bean);
                return recordList;
			}
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}

	
	@Override
	public BuyStockInfoBean showBuyStock(UserInfoBean userBean,StockInfoBean stockBean,BuyStockInfoBean buyStockBean) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
      	BuyStockInfoBean buyBean= new BuyStockInfoBean();
		
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
			UserInfoBean userInfoBean= entityManager.find(UserInfoBean.class, userBean.getUserId());
			StockInfoBean stockBean1= entityManager.find(StockInfoBean.class,stockBean.getId());
              
			if(userBean!=null && stockBean1!=null) {
				if(stockBean1.getQuantity()>= stockBean.getQuantity() && stockBean1.getPrice() >= stockBean.getPrice()) {
				
					buyStockBean.setProductName(stockBean1.getProductName());
				
				buyBean.setType(stockBean1.getType());

				 buyBean.setPrice(stockBean1.getPrice());
				 buyBean.setQuantity(stockBean1.getQuantity());
				 buyBean.setId(userBean.getUserId());
				 buyBean.setUserName(userBean.getUserName());
	            buyBean.setId(stockBean1.getId());
	             entityManager.persist(buyBean);
                 entityTransaction.commit();
                 System.out.println("record saved");
			
                  return buyBean;
				}else {
					System.out.println("no of products and costs are overloaded");
				}
	      }else {
	    	  return null;
	      }
		}
		catch(Exception e) {
			entityTransaction.rollback();
		}
		entityManager.close();
		entityManagerFactory.close();
		return null;
	}

	


}

package com.jfsfeb.stockmanagementsystemjpawithhibernate.controller;

import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.Factory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.services.CompanyService;
import lombok.extern.log4j.Log4j;

@Log4j
public class ManagerController {
	
	public void companyManagerController() {

		long mobileNumber = 0;
		int id = 0;
		String productName = null;
		String type = null;
		double price = 0.0;
		int quantity = 0;
		String emailId = null;
		String password = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		CompanyService service2 = Factory.getCompanyServiceImplInstance();
		log.info("------------Welcome--------");
		log.info("------Enter Details For Login-----");
		log.info("Enter EmailId :");
		emailId = scanner.next();
		log.info("Enter Password :");
		password = scanner.next();
		try {
			@SuppressWarnings("unused")
			ManagerInfoBean login = service2.managerLogin(emailId, password);
			log.info("---- Login Success!! ----");

			do {
				try {
					log.info("=======================================");
					log.info("Enter [1] To Change Password");
					log.info("Enter [2] To Add Stock");
					log.info("Enter [3] To Update The Product");
					log.info("Enter [4] To Remove Stock");
					log.info("Enter [5] To Get Stock Using Product Name");
					log.info("Enter [6] To Get All Stocks");
					log.info("Enter [7] To Logout");
					log.info("======================================");
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:
					log.info("Enter Mobile Number:");
						mobileNumber = scanner.nextLong();
						log.info("Enter New Password :");
						password = scanner.next();
						if (mobileNumber == 0) {
							log.info("Enter the Valid mobilenumber");
						} else {
							Random random = new Random();
							int otp = random.nextInt(10000);
							log.info(otp < 0 ? otp * -1 : otp);
							log.info("please ,enter otp ");
							int typeOtp = scanner.nextInt();
							if (otp == typeOtp) {

								ManagerInfoBean bean = new ManagerInfoBean();
								bean.setMobileNumber(mobileNumber);
								bean.setPassword(password);
								boolean update = service2.modifyPassword(mobileNumber, password);
								if (update) {
									log.info("password updated succesfully");

								} else {
									System.err.println("password is not updated");
								}
							} else {
								System.err.println("otp mismatched");
							}
						}

						break;

					case 2:

						log.info("Enter stock ID :");
						id = scanner.nextInt();
						log.info("Enter Product Name :");
						productName = scanner.next();
						log.info("Enter Type :");
						type = scanner.next();
						log.info("Enter Price");
						price = scanner.nextDouble();
						log.info("Enter Number of Products");
						quantity = scanner.nextInt();
						StockInfoBean bean1 = new StockInfoBean();
						bean1.setId(id);
						bean1.setProductName(productName);
						bean1.setType(type);
						bean1.setPrice(price);
						bean1.setQuantity(quantity);
						boolean check2 = service2.insertStocks(bean1);
						if (check2) {
							log.info("stock is Added Successfully");
							log.info(String.format("%-5s %-20s %-20s %-20s %s", bean1.getId(), bean1.getProductName(),
									bean1.getType(), bean1.getPrice(), bean1.getQuantity()));
						} else {
							log.info("stock already exist");
						}

						break;

					case 3:
						log.info("enter  Stock_Id");
						int stockId = scanner.nextInt();
						log.info("Enter the new stock_type :");
						String stockName = scanner.next();

						if (stockId == 0) {
							log.info("Enter the Valid stock_id");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setId(stockId);
							bean6.setType(stockName);
							boolean update = service2.modifyStockNameUsingId(stockId, stockName);
							if (update) {
								log.info("  stock is succesfully updated  ");
							} else {
								System.err.println("stock is not updated");
							}
						}

						break;
					
						

					case 4:
						log.info("Enter the stock Id to remove :");
						int stockId1 = scanner.nextInt();
						if (stockId1 == 0) {
							log.info("Enter the Valid stock_Id");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setId(id);
							boolean remove = service2.removeStocks(id);
							if (remove) {
								System.err.println("The stock is removed successfully");
							} else {
								System.err.println("The stock is not removed");
							}
						}
						break;

					case 5:

						log.info("  Get The Stock Using Product Name :");
						String stockName1 = scanner.next();

						List<StockInfoBean> stockName2 = service2.viewStockUsingName(stockName1);
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Product", "Type",
								"Price", "Quantity"));
						for (StockInfoBean StockInfoBean : stockName2) {
							if (StockInfoBean != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(),StockInfoBean.getType(), StockInfoBean.getPrice(),
										StockInfoBean.getQuantity()));
							} else {
								log.info("No stocks  available with this Name");
							}
						}

						break;

					

					case 6:
						List<StockInfoBean> info = service2.viewStockDetails();
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Product", "Type",
								"Price", "Quantity"));
						for (StockInfoBean StockInfoBean : info) {

							if (StockInfoBean != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(), StockInfoBean.getType(),StockInfoBean.getPrice(),
										StockInfoBean.getQuantity() ));

							} else {
								log.info("No Stocks Available");
							}
						}
						break;

					case 7:
						companyManagerController();
						break;
					default:
						System.err.println("please enter valid choice between 1-8");
					}

				} catch (Exception e) {
					log.info("should contain only digits");
					companyManagerController();
				}
			} while (true);

		} catch (Exception e) {
			log.info("enter valid email and password");
			companyManagerController();
		}

	}

}

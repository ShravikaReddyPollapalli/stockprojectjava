package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;



public interface AdminDAO {
	
	boolean managerRegistration(ManagerInfoBean managerInfoBean);

	boolean modifyManager(String emailId, int id);

	boolean deleteManager(int id);

	List<ManagerInfoBean> viewManagerDetails();

	boolean insertCompany(CompanyInfoBean companyInfoBean);

	boolean modifyCompany(int id, String companyName);

	boolean deleteCompany(int id,String companyName);

	List<CompanyInfoBean> viewCompanyDetails();

	boolean adminRegistration(AdminInfoBean adminInfoBean);

	AdminInfoBean authenticateAdmin(String emailId, String password);
}

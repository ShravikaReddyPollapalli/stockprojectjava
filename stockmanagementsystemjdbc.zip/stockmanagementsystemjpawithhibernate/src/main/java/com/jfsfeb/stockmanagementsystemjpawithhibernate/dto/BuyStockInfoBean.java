package com.jfsfeb.stockmanagementsystemjpawithhibernate.dto;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="buyinfo")
public class BuyStockInfoBean  {
	@Id
	@Column
	private int id;
	@Column
	private String productName;
	@Column
	private String type;
	@Column
	private double price;
	@Column
	private int quantity;
	@Column
	private int userId;
	@Column
	private String userName;
}

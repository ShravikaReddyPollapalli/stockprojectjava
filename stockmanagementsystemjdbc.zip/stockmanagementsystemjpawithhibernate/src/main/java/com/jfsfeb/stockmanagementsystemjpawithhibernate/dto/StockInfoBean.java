package com.jfsfeb.stockmanagementsystemjpawithhibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name="stock")
public class StockInfoBean implements Serializable {
	@Id
	@Column
	   private int id;
	@Column
	   private String productName;
	@Column
	   private String type;
	@Column
	   private double price;
	@Column
	   private int quantity;
	   
}
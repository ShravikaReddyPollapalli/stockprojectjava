package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.AdminDAO;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.Factory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.validation.Validation;

public class AdminServiceImpl implements AdminService {

	AdminDAO dao = Factory.getAdminDAOImplInstance();
	Validation validation = Factory.getValidationInstance();

	@Override
	public boolean managerRegistration(ManagerInfoBean managerInfoBean) {
		if (managerInfoBean != null) {
			if (validation.validatedEmail(managerInfoBean.getEmailId())) {
				if (validation.validatedPassword(managerInfoBean.getPassword())) {
					if (validation.validatedName(managerInfoBean.getUserName())) {
						if (validation.validatedId(managerInfoBean.getUserId())) {
							if (validation.validatedMobile(managerInfoBean.getMobileNumber())) {
								if (validation.validatedName(managerInfoBean.getUserName()))
									return dao.managerRegistration(managerInfoBean);

							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public boolean deleteManager(int id) {
		if (id != 0) {
			return dao.deleteManager(id);
		}
		return false;
	}

	@Override
	public boolean modifyManager(String mail, int id) {
		if (mail != null && id != 0) {
			if (validation.validatedEmail(mail)) {
				if (validation.validatedId(id)) {

					return dao.modifyManager(mail, id);
				}
			}
		}
		return false;
	}

	@Override
	public boolean insertCompany(CompanyInfoBean companyInfoBean) {
		if (companyInfoBean != null) {
			if (validation.validatedId(companyInfoBean.getCompanyId())) {
				if (validation.validatedName(companyInfoBean.getCompanyName())) {
					return dao.insertCompany(companyInfoBean);
				}

			}
		}
		return false;
	}

	@Override
	public boolean deleteCompany(int id, String companyName) {
		if (companyName != null) {
			if (validation.validatedName(companyName)) {

				return dao.deleteCompany(id, companyName);
			}
		}
		return false;
	}

	@Override
	public boolean modifyCompany(int id, String cName) {
		if (id != 0 && cName != null) {
			if (validation.validatedId(id)) {
				if (validation.validatedName(cName)) {
					return dao.modifyCompany(id, cName);
				}
			}
		}
		return false;
	}

	@Override
	public boolean adminRegistration(AdminInfoBean admin) {
		// TODO Auto-generated method stub
		return dao.adminRegistration(admin);
	}

	@Override
	public List<ManagerInfoBean> viewManagerDetails() {
		// TODO Auto-generated method stub
		return dao.viewManagerDetails();
	}

	@Override
	public AdminInfoBean authenticateAdmin(String email, String password) {
		if (validation.validatedEmail(email)) {
			if (validation.validatedPassword(password)) {
				return dao.authenticateAdmin(email, password);
			}

		}
		return null;
	}

	@Override
	public List<CompanyInfoBean> viewCompanyDetails() {
		// TODO Auto-generated method stub
		return dao.viewCompanyDetails();
	}

}

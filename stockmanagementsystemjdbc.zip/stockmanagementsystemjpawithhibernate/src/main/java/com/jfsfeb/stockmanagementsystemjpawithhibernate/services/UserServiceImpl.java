package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dao.UserDAO;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.factory.Factory;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.validation.Validation;



public class UserServiceImpl implements UserService{

	UserDAO dao = Factory.getUserDAOImplInstance();
	Validation validation = Factory.getValidationInstance();
	@Override
	public UserInfoBean userLogin(String email, String password) {
		if (email != null && password != null) {
			if (validation.validatedEmail(email)) {
				if (validation.validatedPassword(password)) {
					return dao.userLogin(email, password);
				}
			}
		}
		return null;
	}

	@Override
	public boolean modifyPassword(long regMobile, String regPassword) {
		// TODO Auto-generated method stub
		return dao.modifyPassword(regMobile, regPassword);
	}

	@Override
	public boolean userRegistration(UserInfoBean user) {
		if (user != null) {
			if (validation.validatedId(user.getUserId())) {
				if (validation.validatedName(user.getUserName())) {
					if (validation.validatedMobile(user.getMobileNumber())) {
						if (validation.validatedEmail(user.getEmailId())) {
							if (validation.validatedPassword(user.getPassword())) {
								return dao.userRegistration(user);
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public List<StockInfoBean> viewStockDetails() {
		// TODO Auto-generated method stub
		return dao.viewStockDetails();
	}

	public BuyStockInfoBean showBuyStock(UserInfoBean user, StockInfoBean stockBean,BuyStockInfoBean buyStockBean) {
		if(user != null && stockBean != null) {
			if(validation.validatedId(stockBean.getId())) {
				if(validation.validatedId(user.getUserId())) {
					return dao.showBuyStock(user,stockBean,buyStockBean);
				}
			}
		}
		return null;
	}

	

	
}

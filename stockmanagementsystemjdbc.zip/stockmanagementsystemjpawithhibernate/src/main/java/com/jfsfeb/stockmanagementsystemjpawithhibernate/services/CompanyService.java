package com.jfsfeb.stockmanagementsystemjpawithhibernate.services;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.StockInfoBean;

public interface CompanyService {

	ManagerInfoBean managerLogin(String emailId, String password);

	boolean modifyPassword(long mobileNumber, String password);

	boolean insertStocks(StockInfoBean stockBean);

	boolean modifyStockNameUsingId(int id, String productName);

	boolean removeStocks(int id);

	List<StockInfoBean> viewStockDetails();

	List<StockInfoBean> viewStockUsingName(String productName);
}

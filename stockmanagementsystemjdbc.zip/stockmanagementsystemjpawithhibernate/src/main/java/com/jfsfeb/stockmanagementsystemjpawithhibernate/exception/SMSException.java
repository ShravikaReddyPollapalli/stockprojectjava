package com.jfsfeb.stockmanagementsystemjpawithhibernate.exception;

@SuppressWarnings("serial")
public class SMSException extends RuntimeException {
	public SMSException(String msg) {
			
			super(msg);
			
		}
}

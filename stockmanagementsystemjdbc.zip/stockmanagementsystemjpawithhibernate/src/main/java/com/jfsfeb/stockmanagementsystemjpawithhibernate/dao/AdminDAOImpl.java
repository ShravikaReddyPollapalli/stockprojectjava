package com.jfsfeb.stockmanagementsystemjpawithhibernate.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjpawithhibernate.dto.ManagerInfoBean;

public class AdminDAOImpl implements AdminDAO {

	@Override
	public boolean managerRegistration(ManagerInfoBean managerInfoBean) {
		ManagerInfoBean bean = new ManagerInfoBean();
		bean.setUserId(managerInfoBean.getUserId());
		bean.setUserName(managerInfoBean.getUserName());
		bean.setEmailId(managerInfoBean.getEmailId());
		bean.setPassword(managerInfoBean.getPassword());
		bean.setMobileNumber(managerInfoBean.getMobileNumber());
		bean.setRole(managerInfoBean.getRole());
		
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
				entityManager.persist(bean);
				System.out.println("record is saved");
				entityTransaction.commit();
				return true;

		}catch(Exception e) {
			entityTransaction.rollback();
		} 
		
		entityManager.close();
		entityManagerFactory.close();
		return false;	
	}

	@Override
	public boolean modifyManager(String emailId, int id) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    ManagerInfoBean update =entityManager.find(ManagerInfoBean.class,id);
		update.setEmailId(emailId);
		System.out.println("record is updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;
	}

	@Override
	public boolean deleteManager(int id) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
		    entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();

			ManagerInfoBean bean =entityManager.find(ManagerInfoBean.class, id);
			int testId=bean.getUserId();
			if(testId!=0) {
				entityManager.remove(bean);
				System.out.println("record deleted successfully");
				entityTransaction.commit();
				return true;
			}
		  }catch(Exception e) {
	          e.printStackTrace(); 
	     }
			
			entityManager.close();
			entityManagerFactory.close();
			return false;
	}

	@Override
	public List<ManagerInfoBean> viewManagerDetails() {
		ManagerInfoBean  bean= new ManagerInfoBean();
		
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select m from ManagerInfoBean m where m.role='manager'";
		
		Query query = manager.createQuery(jpql);
		List<ManagerInfoBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(ManagerInfoBean objects : recordList ) {

				bean.setUserId(objects.getUserId());
				bean.setUserName(objects.getUserName());
				bean.setMobileNumber(objects.getMobileNumber());
				bean.setEmailId(objects.getEmailId());
				bean.setPassword(objects.getPassword());
				bean.setRole(objects.getRole());
                recordList.add(bean);
                return recordList;
               
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
		
		
	}

	@Override
	public boolean insertCompany(CompanyInfoBean companyInfoBean) {
		CompanyInfoBean bean = new CompanyInfoBean();
		bean.setCompanyId(bean.getCompanyId());
		bean.setCompanyName(bean.getCompanyName());
			
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.persist(bean);
			System.out.println("record is saved");
			entityTransaction.commit();
			return true;
		}catch(Exception e) {
			entityTransaction.rollback();
		} 
		
		entityManager.close();
		entityManagerFactory.close();
		return false;	
	}
	
	@Override
	public boolean modifyCompany(int id, String companyName) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		
	    CompanyInfoBean update =entityManager.find(CompanyInfoBean.class,id);
		update.setCompanyName(companyName);
		System.out.println("record is updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;


	}

	@Override
	public boolean deleteCompany(int id ,String companyName) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		EntityTransaction entityTransaction= null;
		try {
		 entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
	    CompanyInfoBean update =entityManager.find(CompanyInfoBean.class,id);
		update.setCompanyName(companyName);
		System.out.println("record updated");
		entityTransaction.commit();
		return true;
		
		}
	   catch(Exception e) {
		entityTransaction.rollback();
	   }
		entityManager.clear();
		entityManagerFactory.close();
		return false;
	}

	@Override
	public List<CompanyInfoBean> viewCompanyDetails() {
		CompanyInfoBean bean= new CompanyInfoBean();
		EntityManagerFactory entityManagerfactory = Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager manager = entityManagerfactory.createEntityManager(); 
		String jpql = "select c from CompanyInfoBean c ";
		
		Query query = manager.createQuery(jpql);
		List<CompanyInfoBean> recordList = query.getResultList();
		if(recordList!=null) {
			for(CompanyInfoBean objects : recordList ) {

				bean.setCompanyId(objects.getCompanyId());
				bean.setCompanyName(objects.getCompanyName());
				
                return recordList;
			}
			
		}
		manager.close();
		entityManagerfactory.close();
		return null;
	}

	@Override
	public boolean adminRegistration(AdminInfoBean adminInfoBean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public AdminInfoBean authenticateAdmin(String emailId, String password) {
		EntityManagerFactory entityManagerFactory= null;
		EntityManager entityManager= null;
		

		try  {
		entityManagerFactory = Persistence.createEntityManagerFactory("TestPersistence");
		entityManager = entityManagerFactory.createEntityManager(); 
		String jpql="select a from AdminInfoBean a where a.emailId=:mail and a.password=:password and a.role='admin'";
		TypedQuery<AdminInfoBean> query = entityManager.createQuery(jpql,AdminInfoBean.class);
		query.setParameter("mail", emailId);
		query.setParameter("password", password);
		AdminInfoBean bean = query.getSingleResult();
		return bean;
		}catch(Exception e){
		System.err.println(e.getMessage());
		return null;
	  }finally {
		entityManager.close();
		entityManagerFactory.close();
	  }
	
		
	}
}

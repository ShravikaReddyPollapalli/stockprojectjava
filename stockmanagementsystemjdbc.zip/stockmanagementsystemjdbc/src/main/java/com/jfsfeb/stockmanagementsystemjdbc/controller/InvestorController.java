package com.jfsfeb.stockmanagementsystemjdbc.controller;

import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.jfsfeb.stockmanagementsystemjdbc.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjdbc.factory.Factory;
import com.jfsfeb.stockmanagementsystemjdbc.service.InvestorService;
import lombok.extern.log4j.Log4j;

@Log4j
public class InvestorController {
	public void investorController() {
      
        int userId=0;
		String userName = null;
		String emailId = null;
		String password = null;
		long mobileNumber = 0;
		String role = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		InvestorService service = Factory.getUserServiceImpl();

		try {
			do {
				try {
					log.info("==========================================");
					log.info("Enter [1] To Investor Register");
					log.info("Enter [2] To Investor Login");
					log.info("Enter [3] To Exit");
					log.info("============================================");
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:

						log.info("Enter ID :");
						userId = scanner.nextInt();
						log.info("Enter Name :");
						userName = scanner.next();
						
						log.info("Enter Email :");
						emailId = scanner.next();
						log.info("Enter Password :");
						password = scanner.next();
						log.info("Enter Mobile :");
						mobileNumber = scanner.nextLong();
						log.info("Enter Role :");
						role = scanner.next();
						UserInfoBean bean1 = new UserInfoBean();
						bean1.setUserId(userId);
						bean1.setUserName(userName);
						bean1.setEmailId(emailId);
						bean1.setPassword(password);
						bean1.setMobileNumber(mobileNumber);
						bean1.setRole(role);
						boolean check = service.userRegistration(bean1);
						if (check) {
							log.info("Registered");
						} else {
							log.info("Email already exist");
						}
						break;

					case 2:

						log.info("Enter Email :");
						emailId = scanner.next();
						log.info("Enter Password :");
						password = scanner.next();
						try {
							@SuppressWarnings("unused")
							UserInfoBean login = service.userLogin(emailId, password);
							log.info("     Login Success!!    ");
							do {
								try {
									log.info("==============================================");
									log.info("Enter [1] To Change Password");
									log.info("Enter [2] To Get Stock Details");
									log.info("Enter [3] To Buy Stock");
									log.info("Enter [4] To Logout");
									log.info("==============================================");

									int choice2 = scanner.nextInt();
									switch (choice2) {

									case 1:

										log.info("Enter Mobile :");
										mobileNumber = scanner.nextLong();
										log.info("Enter New Password :");
										password = scanner.next();
										if (mobileNumber == 0) {
											log.info("Enter the Valid Mobile Number");
										} else {
											Random random = new Random();
											int otp = random.nextInt(9999);
											log.info(otp < 0 ? otp * -1 : otp);
											log.info("Provide OTP Here");
											int typeOtp = scanner.nextInt();
											if (otp == typeOtp) {

												UserInfoBean bean = new UserInfoBean();
												bean.setMobileNumber(mobileNumber);
												bean.setPassword(password);
												boolean update = service.modifyPassword(mobileNumber, password);
												if (update) {
													log.info("password is updated ");
												} else {
													log.error("password is not updated");
												}
											} else {
												log.error("otp mismatched");
											}
										}

										break;

									
											case 2:
												List<StockInfoBean> info12 = service.viewStockDetails();
												log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "product", "type",
														"price", "quantity"));
												for (StockInfoBean StockInfoBean : info12) {

													if (StockInfoBean != null) {
														log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
																StockInfoBean.getProductName(),StockInfoBean.getType(),
																StockInfoBean.getQuantity(),StockInfoBean.getPrice()));

													} else {
														log.info("No stock Information");
													}
												}
												break;
									case 3:
										System.out.println("Enter stock id");
										int bId = scanner.nextInt();
										StockInfoBean stockBean = new  StockInfoBean();
										stockBean.setId(bId);

										System.out.println("Enter user id");
										int userId1 = scanner.nextInt();
										UserInfoBean userBean = new UserInfoBean();
										userBean.setUserId(userId1);
										
                                        BuyStockInfoBean bean= new BuyStockInfoBean();
										try {
										boolean request = service.buyStock(userBean, stockBean);
											System.out.println("Buy stock information");
					
											if(request!=false) {
											       System.out.println("product added  to the cart");
											}else {
												System.err.println();
											}
										} catch (SMSException e) {

											System.out.println("No Product Available");
										}
										break;

									case 4:
										investorController();
										break;

									default:
										log.error("please enter valid choice between 1-7");
										break;
									}

								} catch (Exception e) {

									log.info("stock not found");
								}
							} while (true);

						} catch (Exception e) {
							log.error("invalid credentials ..please try again!!");
						}
						break;

					case 3:
						investorController();
						break;
					default:
						log.error("please enter choice betweem 1-3");

					}

				} catch (Exception e) {
					System.out.println("should contain only digits");
					investorController();
				}
			} while (true);

		} catch (Exception e) {
			System.out.println("enter valid email and password");
			investorController();
		}

	}

}

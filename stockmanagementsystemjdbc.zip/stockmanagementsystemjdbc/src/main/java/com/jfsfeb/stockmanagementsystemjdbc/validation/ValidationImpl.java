package com.jfsfeb.stockmanagementsystemjdbc.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;


public class ValidationImpl implements Validation {
	
	public boolean validatedId(int id) throws SMSException {
		String idRegEx = "[0-9]{1}[0-9]{1}" ;
		boolean result = false;
		if (Pattern.matches(idRegEx, String.valueOf(id))) {
			result = true;
		} else {
			throw new SMSException("Id should contains exactly 2 digits");
		}
		return result;
	}
	public boolean validatedName(String name) throws SMSException {
		String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$" ;
		boolean result = false;
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new SMSException("Name should  contains only Alphabates");
		}
		return result;
	}
	public boolean validatedMobile(long mobile) throws SMSException {
		String mobileRegEx = "(0/91)?[6-9][0-9]{9}" ;
		boolean result = false;
		if (Pattern.matches(mobileRegEx, String.valueOf(mobile))) {
			result = true;
		} else {
			throw new SMSException("Mobile Number  will start with  6 or 9 and It should contains 10 numbers");
		}
		return result;
	}
	public boolean validatedEmail(String email) throws SMSException {
		String emailRegEx = "^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$";
		boolean result = false;
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new SMSException("email id should sequence of characters with @ and .com");
		}
		return result;
	}
	public boolean validatedPassword(String password) throws SMSException {
		String passwordRegEx = "^(?=[^\\d_].*?\\d)\\w(\\w|[!@#$%]){7,20}" ;
		boolean result = false;
		if (Pattern.matches(passwordRegEx, String.valueOf(password))) { 
			result = true;
		} else {
			throw new SMSException("Password should contain atleast 5 characters ,one uppercase,one lowercase,one symbol"); 
		}
		return result;
	}
	
	
}

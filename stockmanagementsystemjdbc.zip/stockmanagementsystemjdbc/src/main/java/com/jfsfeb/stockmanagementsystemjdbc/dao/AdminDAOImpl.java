package com.jfsfeb.stockmanagementsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.jfsfeb.stockmanagementsystemjdbc.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjdbc.utility.Utility;

public class AdminDAOImpl implements AdminDAO {

	Utility utility = new Utility();

	@Override
	public AdminInfoBean authenticateAdmin(String emailId, String password) {
		AdminInfoBean bean = new AdminInfoBean();
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("authenticateAdmin"))) {

			preparedStatement.setString(1, emailId);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				bean.setUserId(resultSet.getInt("userId"));
				bean.setUserName(resultSet.getString("userName"));
				bean.setEmailId(resultSet.getString("emailId"));
				bean.setPassword(resultSet.getString("password"));
				bean.setMobileNumber(resultSet.getLong("mobileNumber"));
				bean.setRole(resultSet.getString("role"));
				return bean;
			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean managerRegistration(ManagerInfoBean managerInfoBean) {

		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("registerManager"))) {
			preparedStatement.setInt(1, managerInfoBean.getUserId());
			preparedStatement.setString(2, managerInfoBean.getUserName());
			preparedStatement.setString(3, managerInfoBean.getEmailId());
			preparedStatement.setString(4, managerInfoBean.getPassword());
			preparedStatement.setLong(5, managerInfoBean.getMobileNumber());
			preparedStatement.setString(6, managerInfoBean.getRole());

			preparedStatement.executeUpdate();

			return true;
		} catch (Exception e) {
			throw new SMSException("Admin Already Exists");
		}

	}

	@Override
	public boolean modifyManager(String emailId, long mobileNumber) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("updateManager"));) {

			preparedStatement.setString(1, emailId);
			preparedStatement.setLong(2, mobileNumber);
			int count = preparedStatement.executeUpdate();
			if (count != 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public boolean deleteManager(int id) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("removeManager"));) {

			preparedStatement.setInt(1, id);
			int count = preparedStatement.executeUpdate();
			if (count != 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<ManagerInfoBean> viewManagerDetails() {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("getAllCompanyManagerInfo"));) {
			ResultSet resultSet = preparedStatement.executeQuery();
			List<ManagerInfoBean> beans = new ArrayList<ManagerInfoBean>();
			while (resultSet.next()) {
				ManagerInfoBean bean = new ManagerInfoBean();
				bean.setUserId(resultSet.getInt("userId"));
				bean.setUserName(resultSet.getString("userName"));
				bean.setEmailId(resultSet.getString("emailId"));
				bean.setPassword(resultSet.getString("password"));
				bean.setMobileNumber(resultSet.getLong("mobileNumber"));
				bean.setRole(resultSet.getString("role"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean insertCompany(CompanyInfoBean companyInfoBean) {

		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("addCompany"))) {

			preparedStatement.setInt(1, companyInfoBean.getCompanyId());
			preparedStatement.setString(2, companyInfoBean.getCompanyName());
			preparedStatement.executeUpdate();
			
			return true;
		} catch (Exception e) {
			throw new SMSException("company already exist");
		}
	}

	@Override
	public boolean modifyCompany(int id, String companyName) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("updateCompany"));) {
			preparedStatement.setString(1, companyName);
			preparedStatement.setInt(2, id);
			
			int count = preparedStatement.executeUpdate();
			if (count != 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteCompany(String name) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("removeCompany"));) {

			preparedStatement.setString(1, name);
			int count = preparedStatement.executeUpdate();
			if (count != 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public List<CompanyInfoBean> viewCompanyDetails() {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(utility.getQuery("getAllCompanies"));) {
			ResultSet resultSet = preparedStatement.executeQuery();
			List<CompanyInfoBean> beans = new ArrayList<CompanyInfoBean>();
			while (resultSet.next()) {
				CompanyInfoBean bean = new CompanyInfoBean();
				bean.setCompanyId(resultSet.getInt("companyId"));
				bean.setCompanyName(resultSet.getString("companyName"));
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	
}

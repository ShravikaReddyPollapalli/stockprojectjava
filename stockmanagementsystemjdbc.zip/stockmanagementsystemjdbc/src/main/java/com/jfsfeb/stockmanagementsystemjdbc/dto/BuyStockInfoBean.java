package com.jfsfeb.stockmanagementsystemjdbc.dto;





import lombok.Data;
@Data

public class BuyStockInfoBean {
	
	private int productId;
	
	private String productName;
	
	private String type;
	
	private double price;
	
	private int quantity;
	
	private int userId;
	
	private String userName;
}

package com.jfsfeb.stockmanagementsystemjdbc.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjdbc.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.UserInfoBean;


public interface InvestorDAO {
	
	boolean userRegistration(UserInfoBean user);

	UserInfoBean userLogin(String emailId, String password);

	boolean modifyPassword(long mobileNumber, String password);

	BuyStockInfoBean showBuyStock(UserInfoBean userBean,StockInfoBean stockBean,BuyStockInfoBean buyStockBean);

	List<StockInfoBean> viewStockDetails();
	
	boolean buyStock(UserInfoBean user, StockInfoBean stockBean);
	
}

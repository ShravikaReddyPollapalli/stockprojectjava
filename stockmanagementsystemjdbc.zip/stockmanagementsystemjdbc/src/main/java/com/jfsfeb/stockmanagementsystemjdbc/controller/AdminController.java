package com.jfsfeb.stockmanagementsystemjdbc.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.stockmanagementsystemjdbc.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjdbc.factory.Factory;
import com.jfsfeb.stockmanagementsystemjdbc.service.AdminService;
import lombok.extern.log4j.Log4j;

@SuppressWarnings("unused")
@Log4j
public class AdminController {

	public void adminController() {

		int userId = 0;
		String userName = null;
		String emailId = null;
		String password = null;
		long mobileNumber = 0;
		String role = null;
		String loginMail = null;
		String loginPassword = null;
		int companyId = 0;
		String companyName = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		AdminService service = Factory.getAdminServiceImplInstance();

		log.info(" ------------ Welcome -----------");
		log.info(" ------ Enter Details For Login ------");
		log.info("   ");
		log.info("Enter Email :");
		loginMail = scanner.next();
		log.info("Enter Password :");
		loginPassword = scanner.next();
		try {
			@SuppressWarnings("unused")
			AdminInfoBean login = service.authenticateAdmin(loginMail, loginPassword);
			
				System.out.println("You have logged in successfully");
				System.out.println();
				

				do {
					try {
						log.info("=======================================");
						log.info("Enter [1] To add company manager");
						log.info("Enter [2] To update company manager");
						log.info("Enter [3] To remove company manager");
						log.info("Enter [4] To see all company managers");
						log.info("Enter [5] To add company");
						log.info("Enter [6] To update company");
						log.info("Enter [7] To remove company");
						log.info("Enter [8] To see all companies");
						log.info("Enter [9] To Logout");
						log.info("=======================================");

						int choice = scanner.nextInt();

						switch (choice) {

						case 1:

							log.info("Enter ID :");
							userId = scanner.nextInt();
							log.info("Enter Name :");
							userName = scanner.next();
							log.info("Enter Mobile :");
							mobileNumber = scanner.nextLong();
							log.info("Enter Email :");
							emailId = scanner.next();
							log.info("Enter Password :");
							password = scanner.next();
							log.info("Enter Role :");
							role = scanner.next();
							ManagerInfoBean managerBean = new ManagerInfoBean();
							managerBean.setUserId(userId);
							managerBean.setUserName(userName);
							managerBean.setEmailId(emailId);
							managerBean.setPassword(password);
							managerBean.setMobileNumber(mobileNumber);
							managerBean.setRole(role);
							boolean check = service.managerRegistration(managerBean);
							if (check) {
								log.info("Manager Registered successfully");
							} else {
								log.info("Email already exist");
							}

							break;

						case 2:
							log.info("enter mobile number");
							mobileNumber = scanner.nextLong();
							log.info("Enter the  new  emailId  :");
							emailId = scanner.next();

							if (mobileNumber == 0) {
								log.info("Enter The Valid Mobile Number");
							} else {
								ManagerInfoBean managerBean1 = new ManagerInfoBean();
								managerBean1.setMobileNumber(mobileNumber);
								managerBean1.setEmailId(emailId);
								boolean update = service.modifyManager(emailId, mobileNumber);
								if (update) {
									log.info("company manager updated succesfully");
								} else {
									log.error("company manager is not updated");
								}
							}

							break;

						case 3:

							log.info("Enter Manager Id To Remove :");
							int managerId = scanner.nextInt();
							if (managerId == 0) {
								log.info("Enter Valid Manager Id");
							} else {
								ManagerInfoBean managerBean2 = new ManagerInfoBean();
								managerBean2.setUserId(managerId);
								boolean remove = service.deleteManager(managerId);
								if (remove) {
									log.error("company manager removed succesfully");
								} else {
									log.error("company manager is not removed");
								}
							}

							break;

						case 4:
							List<ManagerInfoBean> info2 = service.viewManagerDetails();
							log.info(String.format("%-5s %-20s %-20s %-20s %s", "Id", "Name", "email", "password",
									"mobileNumber","role"));
							for (ManagerInfoBean managerBean3 : info2)  {

								if (managerBean3 != null) {
									log.info(String.format("%-5s %-20s %-20s %-20s %s", managerBean3.getUserId(),
											managerBean3.getUserName(),
											managerBean3.getEmailId(), managerBean3.getPassword(), managerBean3.getMobileNumber(),managerBean3.getRole()));

								} else {
									log.info("no managers are available");
								}
							}

							break;

						case 5:
							log.info("Enter company id :");
							companyId = scanner.nextInt();
							log.info("Enter company name :");
							companyName = scanner.next();
							CompanyInfoBean bean = new CompanyInfoBean();
							bean.setCompanyName(companyName);
							bean.setCompanyId(companyId);
							boolean check2 = service.insertCompany(bean);
							if (check2) {
								log.info("company added succefully");
								log.info(String.format("%-5s", bean.getCompanyName()));
							} else {
								log.info("company  already exist");
							}

							break;

						case 6:
							log.info("enter  company Id");
							int companyId1 = scanner.nextInt();
							log.info("Enter new  company Name :");
							String companyName1 = scanner.next();
							CompanyInfoBean companyBean = new CompanyInfoBean();
							companyBean.setCompanyId(companyId1);
							companyBean.setCompanyName(companyName1);
							if (companyName1 == null) {
								log.info("Enter the Valid companyName");
							} else {
								
								boolean update = service.modifyCompany(companyId1, companyName1);
								if (update) {
									log.info("company updated succesfully");
								} else {
									log.error("company is not updated");
								}
							}

							break;

						case 7:

							log.info("Enter the company name to remove :");

							companyName = scanner.next();

							if (companyName == null) {
								log.info("Enter the Valid company_name");
							} else {
								CompanyInfoBean companyBean2 = new CompanyInfoBean();
								companyBean2.setCompanyName(companyName);
								boolean remove = service.deleteCompany(companyName);
								if (remove) {
									log.error("company removed succesfully");
								} else {
									log.error("company is not removed");
								}
							}

							break;

						case 8:

							List<CompanyInfoBean> info3 = service.viewCompanyDetails();
							log.info(String.format("%-5s %-20s", "company-Id", "company_name"));
							for (CompanyInfoBean companyBean1 : info3) {

								if (companyBean1 != null) {
									log.info(String.format("%-5s %-20s", companyBean1.getCompanyId(),
											companyBean1.getCompanyName()));

								} else {
									log.info("company info is not present");
								}
							}

							break;
						case 9:
							adminController();
							break;
						default:
							log.error("please enter valid choice between 1-9");
						}

					} catch (InputMismatchException e) {
						log.error("should contain only digits");

						adminController();
					} 
				} while (true);

			
		} catch (SMSException e) {
			log.error(e.getMessage());
		}

	}
}

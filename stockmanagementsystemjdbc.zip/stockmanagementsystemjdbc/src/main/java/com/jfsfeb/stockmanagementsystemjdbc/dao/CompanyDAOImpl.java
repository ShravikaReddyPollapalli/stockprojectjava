package com.jfsfeb.stockmanagementsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.stockmanagementsystemjdbc.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjdbc.utility.Utility;

public class CompanyDAOImpl implements CompanyDAO{
Utility utility = new Utility();
	@Override
	public ManagerInfoBean managerLogin(String emailId, String password) {
		ManagerInfoBean admin = new ManagerInfoBean();

		try (Connection connection = utility.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("managerLogin"))){
			
		        preparedStatement.setString(1, emailId);
				preparedStatement.setString(2, password);
				ResultSet resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					ManagerInfoBean bean = new ManagerInfoBean();
					bean.setUserId(resultSet.getInt("userId"));
					bean.setUserName(resultSet.getString("userName"));
					bean.setEmailId(resultSet.getString("emailId"));
					bean.setPassword(resultSet.getString("password"));
					bean.setMobileNumber(resultSet.getLong("mobileNumber"));
					bean.setRole(resultSet.getString("role"));
					
					return bean;
				} else {
					return null;
				}

			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	@Override
	public boolean modifyPassword(long mobileNumber, String password) {
		try (Connection connection = utility.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("modifyPassword1"));) {
			
				preparedStatement.setString(1, password);
				preparedStatement.setLong(2, mobileNumber);
				int count = preparedStatement.executeUpdate();
				if (count != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
	}

	@Override
	public boolean insertStocks(StockInfoBean stockBean) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("insertStocks"))){
				
				preparedStatement.setInt(1, stockBean.getId());
				preparedStatement.setString(2, stockBean.getProductName());
				preparedStatement.setString(3, stockBean.getType());
				preparedStatement.setDouble(4, stockBean.getPrice());
				preparedStatement.setInt(5, stockBean.getQuantity());
				
				int result =preparedStatement.executeUpdate();
				System.out.println(result);
				return true;
			} catch (Exception e) {
				throw new SMSException("please add new stock,entered stock already exists");
			}
	}

	@Override
	public boolean modifyStockNameUsingId(int id, String productName) {
		try (Connection connection = utility.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("modifyStockNameUsingId"));) {

				preparedStatement.setString(1,productName );
				preparedStatement.setInt(2, id);
				int count = preparedStatement.executeUpdate();
				if (count != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
	}

	

	@Override
	public boolean removeStocks(int id) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("removeStocks"));) {

				preparedStatement.setInt(1, id);
				int count =preparedStatement.executeUpdate();
				if (count != 0) {
					return true;
				} else {
					return false;
				}

			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
	}

	@Override
	public List<StockInfoBean> viewStockUsingName(String productName) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("viewStockUsingName"));) {

			preparedStatement.setString(1, productName);
			ResultSet resultSet= preparedStatement.executeQuery();
			List<StockInfoBean> beans = new ArrayList<StockInfoBean>();
			while (resultSet.next()) {
				StockInfoBean bean = new StockInfoBean();
				bean.setId(resultSet.getInt("id"));
				bean.setProductName(resultSet.getString("productName"));
				bean.setType(resultSet.getString("type"));
				
				bean.setPrice(resultSet.getDouble("price"));
				bean.setQuantity(resultSet.getInt("quantity"));
				
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	

	

	@Override
	public List<StockInfoBean> viewStockDetails() {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("viewStockDetails"));) {
			ResultSet resultSet = preparedStatement.executeQuery();
			List<StockInfoBean> beans = new ArrayList<StockInfoBean>();
			while (resultSet.next()) {
				StockInfoBean bean = new StockInfoBean();
				bean.setId(resultSet.getInt("id"));
				bean.setProductName(resultSet.getString("productName"));
				bean.setType(resultSet.getString("type"));
				
				bean.setPrice(resultSet.getDouble("price"));
				bean.setQuantity(resultSet.getInt("quantity"));
				
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}

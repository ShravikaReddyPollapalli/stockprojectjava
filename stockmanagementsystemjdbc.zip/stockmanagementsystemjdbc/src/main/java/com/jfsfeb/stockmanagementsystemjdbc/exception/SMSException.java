package com.jfsfeb.stockmanagementsystemjdbc.exception;

@SuppressWarnings("serial")
public class SMSException extends RuntimeException {
	public SMSException(String msg) {
			
			super(msg);
			
		}
}

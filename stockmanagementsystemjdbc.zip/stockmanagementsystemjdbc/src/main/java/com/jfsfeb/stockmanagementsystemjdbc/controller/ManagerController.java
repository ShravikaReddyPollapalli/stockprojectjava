package com.jfsfeb.stockmanagementsystemjdbc.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


import com.jfsfeb.stockmanagementsystemjdbc.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjdbc.factory.Factory;
import com.jfsfeb.stockmanagementsystemjdbc.service.CompanyService;

import lombok.extern.log4j.Log4j;

@Log4j
public class ManagerController {
	public void companyManagerController() {

		
		long regMobile=0;
		String regPassword = null;
		int id = 0;
		String productName = null;
		String type = null;
		double price = 0.0;
		int quantity = 0;
		String emailId = null;
		String password = null;

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		CompanyService service2 = Factory.getCompanyServiceImplInstance();
		log.info("---------- Welcome ---------");
		log.info("------ Enter Details For Login -----");
		log.info("Enter Email :");
		emailId = scanner.next();
		log.info("Enter Password :");
		password = scanner.next();
		try {
			@SuppressWarnings("unused")
			ManagerInfoBean login = service2.managerLogin(emailId, password);
			log.info("***** Login Success *****");

			do {
				try {
					log.info("=====================================");
					log.info("Enter [1] to modify password");
					log.info("press [2] to add stock");
					log.info("press [3] to update the stock name");
					log.info("press [4] to remove stock");
					log.info("press [5] to search stock by product name");
					log.info("press [6] to get the all stock");
					log.info("press [7] to Logout");
					log.info("=====================================");
					int choice = scanner.nextInt();
					switch (choice) {

					case 1:

						log.info("Enter Mobile :");
						regMobile = scanner.nextLong();

						log.info("Enter new  Password :");
						regPassword = scanner.next();

						if (regMobile == 0) {
							log.info("Enter the Valid mobile number");
						} else {

							Random random = new Random();
							int otp = random.nextInt(9999);
							log.info(otp<0?otp*-1:otp);
							log.info("Enter otp here ");
							int typeOtp = scanner.nextInt();
							if (otp == typeOtp) {

								ManagerInfoBean bean = new ManagerInfoBean();
								bean.setMobileNumber(regMobile);
								bean.setPassword(regPassword);
								boolean update = service2.modifyPassword(regMobile, regPassword);
								if (update) {
									log.info("password updated succesfully");

								} else {
									log.error("password is not updated");
								}
							} else {
								log.error("otp mismatched");
							}
						}

						break;

					case 2:

						log.info("Enter stock-ID :");
						id = scanner.nextInt();
						log.info("Enter stock Name :");
						productName = scanner.next();
						log.info("Enter Type :");
						type = scanner.next();
						log.info("enter Price");
						price = scanner.nextDouble();
						log.info("enter no of products");
						quantity = scanner.nextInt();
						StockInfoBean bean1 = new StockInfoBean();
						bean1.setId(id);
						bean1.setProductName(productName);
						bean1.setType(type);
						bean1.setPrice(price);
						bean1.setQuantity(quantity);
						boolean check2 = service2.insertStocks(bean1);
						if (check2) {
							log.info("stock Added");
							log.info(String.format("%-5s %-20s %-20s %-20s %s", bean1.getId(), bean1.getProductName(),
									bean1.getType(), bean1.getPrice(), bean1.getQuantity()));
						} else {
							log.info("stock already exist");
						}

						break;

					case 3:
						log.info("enter  Stock_Id");
						int sId = scanner.nextInt();
						log.info("Enter the new stock name :");
						String sName = scanner.next();

						if (sId == 0) {
							log.info("Enter the Valid stock_id");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setId(sId);
							bean6.setType(sName);
							boolean update = service2.modifyStockNameUsingId(sId, sName);
							if (update) {
								log.info("stock updated succesfully");
							} else {
								log.error("stock is not updated");
							}
						}

						break;
					
					
					case 4:
						log.info("Enter the stock_Id to delete :");
						int id1 = scanner.nextInt();
						if (id1 == 0) {
							log.info("Enter the Valid stock_Id");
						} else {
							StockInfoBean bean6 = new StockInfoBean();
							bean6.setId(id1);
							boolean remove = service2.removeStocks(id1);
							if (remove) {
								log.error("The stock is removed");
							} else {
								log.error("The stock is not removed");
							}
						}
						break;

					

					case 5:

						log.info("get the stock by the product Name:");
						String comName = scanner.next();

						List<StockInfoBean> company = service2.viewStockUsingName(comName);
						
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "stock-Id", "company", "cost",
								"no of products", "type of stock"));
						for (StockInfoBean StockInfoBean : company) {

							if (StockInfoBean != null) {

								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(), StockInfoBean.getPrice(),
										StockInfoBean.getQuantity(), StockInfoBean.getType()));
							
							} else {
								log.error("No stocks are available with this companyname");
							}
						}

						break;

					case 6:
						
						List<StockInfoBean> info12 = service2.viewStockDetails();
						log.info(String.format("%-5s %-20s %-20s %-20s %s", "Book-Id", "company", "cost",
								"no of products", "type of stock"));
						for (StockInfoBean StockInfoBean : info12) {

							if (StockInfoBean != null) {
								log.info(String.format("%-5s %-20s %-20s %-20s %s", StockInfoBean.getId(),
										StockInfoBean.getProductName(), StockInfoBean.getPrice(),
										StockInfoBean.getQuantity(), StockInfoBean.getType()));

							} else {
								log.info("stock info is not present");
							}
						}
						break;

					case 7:
						companyManagerController();
						break;
					default:
						log.error("please enter valid choice between 1-7");
					}

				} catch (InputMismatchException e) {
					System.out.println("should contain only digits");
					companyManagerController();
				}
			} while (true);

		} catch (SMSException e) {

			log.error(e.getMessage());
		}

	}

}

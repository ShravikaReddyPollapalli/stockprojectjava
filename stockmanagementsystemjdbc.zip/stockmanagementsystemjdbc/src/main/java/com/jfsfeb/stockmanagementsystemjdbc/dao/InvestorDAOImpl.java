package com.jfsfeb.stockmanagementsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.stockmanagementsystemjdbc.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.exception.SMSException;
import com.jfsfeb.stockmanagementsystemjdbc.utility.Utility;

public class InvestorDAOImpl implements InvestorDAO {
Utility utility = new Utility();
	@Override
	public UserInfoBean userLogin(String emailId, String password) {
		UserInfoBean admin = new UserInfoBean();

		try (Connection connection = utility.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("userLogin"))){
			
		        preparedStatement.setString(1, emailId);
				preparedStatement.setString(2, password);
				ResultSet resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					UserInfoBean bean = new UserInfoBean();
					bean.setUserId(resultSet.getInt("userId"));
					bean.setUserName(resultSet.getString("userName"));
					bean.setEmailId(resultSet.getString("emailId"));
					bean.setPassword(resultSet.getString("password"));
					bean.setMobileNumber(resultSet.getLong("mobileNumber"));
					bean.setRole(resultSet.getString("role"));
					
					return bean;
				} else {
					return null;
				}

			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
	}

	@Override
	public boolean modifyPassword(long mobileNumber, String password) {
		try (Connection connection = utility.getConnection();
				 PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("modifyPassword"));) {

				preparedStatement.setString(1, password);
				preparedStatement.setLong(2,mobileNumber);
				int count = preparedStatement.executeUpdate();
				if (count != 0) {
					    return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
	}

	@Override
	public boolean userRegistration(UserInfoBean user) {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("userRegistration"))){
				
				preparedStatement.setInt(1, user.getUserId());
				preparedStatement.setString(2, user.getUserName());
				
				preparedStatement.setString(3, user.getEmailId());
				preparedStatement.setString(4, user.getPassword());
				preparedStatement.setLong(5, user.getMobileNumber());
				preparedStatement.setString(6, user.getRole());

				int result=preparedStatement.executeUpdate();
				System.out.println(result);
				return true;
			} catch (Exception e) {
				throw new SMSException("Investor already registred ,please try to login");
			}
	}

	

	@Override
	public List<StockInfoBean> viewStockDetails() {
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("viewStockDetails"));) {
			ResultSet resultSet = preparedStatement.executeQuery();
			List<StockInfoBean> beans = new ArrayList<StockInfoBean>();
			while (resultSet.next()) {
				StockInfoBean bean = new StockInfoBean();
				bean.setId(resultSet.getInt("id"));
				bean.setProductName(resultSet.getString("ProductName"));
				bean.setType(resultSet.getString("type"));
				bean.setPrice(resultSet.getDouble("price"));
				bean.setQuantity(resultSet.getInt("quantity"));
				
				beans.add(bean);
			}
			return beans;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public BuyStockInfoBean showBuyStock(UserInfoBean userBean, StockInfoBean stockBean,
			BuyStockInfoBean buyStockBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean buyStock(UserInfoBean user, StockInfoBean stockBean) {
		BuyStockInfoBean beans= new BuyStockInfoBean();
		try (Connection connection = utility.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(utility.getQuery("buyStock1"));) {
			preparedStatement.setInt(1, stockBean.getId());
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				
				System.out.println(stockBean.getId());

				if(resultSet.getInt("id") == stockBean.getId())
				{
					try(Connection connection1 = utility.getConnection();
							PreparedStatement preparedStatement1 = connection1.prepareStatement(utility.getQuery("buyStock2"));) {

						preparedStatement1.setInt(1, user.getUserId());

						ResultSet resultSet1 = preparedStatement1.executeQuery();
						while (resultSet1.next()) {

							
							System.out.println(user.getUserId());

							if(resultSet1.getInt("userId") == user.getUserId()) {


								try (Connection connection2 = utility.getConnection();
									PreparedStatement preparedStatement3 = connection2.prepareStatement(utility.getQuery("buyStock3"))){

                                     System.out.println(resultSet.getString("productName"));
                                     System.out.println(resultSet.getInt("quantity"));
                                     System.out.println(resultSet1.getString("UserName"));
                                     System.out.println("----------------------------");
                                     
									preparedStatement3.setInt(1, resultSet.getInt("id"));
									preparedStatement3.setString(2, resultSet.getString("productName"));
									preparedStatement3.setString(3, resultSet.getString("type"));
									
									preparedStatement3.setDouble(4, resultSet.getDouble("price"));
									preparedStatement3.setInt(5, resultSet.getInt("quantity"));
									preparedStatement3.setInt(6, resultSet1.getInt("userId"));
									preparedStatement3.setString(7,resultSet1.getString("userName"));

									int p=preparedStatement3.executeUpdate();
									System.out.println(p);
									
									
                                    if(p!=0) {
									      return true;
                                    }else {
                                    	return false;
                                    }

								} catch (SQLException e) {
									throw new SMSException("stock already existed ,please add new stock");
								}


							}else {
								System.err.println("investor id is not availble,please login first !!");
								return false;
							}

						}
					}
				}else {
					System.err.println("stock id is not available!!");
					return false;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	
}

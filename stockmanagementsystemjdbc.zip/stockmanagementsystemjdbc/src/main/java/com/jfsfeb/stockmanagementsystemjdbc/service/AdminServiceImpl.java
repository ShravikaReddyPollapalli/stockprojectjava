package com.jfsfeb.stockmanagementsystemjdbc.service;


import java.util.List;
import com.jfsfeb.stockmanagementsystemjdbc.dao.AdminDAO;
import com.jfsfeb.stockmanagementsystemjdbc.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.ManagerInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.factory.Factory;

import com.jfsfeb.stockmanagementsystemjdbc.validation.Validation;

public class AdminServiceImpl implements AdminService {

    AdminDAO dao=Factory.getAdminDAOImplInstance();
		Validation validation = Factory.getValidationInstance();
	
	@Override
	public boolean managerRegistration(ManagerInfoBean managerInfoBean) {
		if (managerInfoBean != null) {
			if (validation.validatedEmail(managerInfoBean.getEmailId())) {
				if (validation.validatedPassword(managerInfoBean.getPassword())) {
					if (validation.validatedName(managerInfoBean.getUserName())) {
						if (validation.validatedId(managerInfoBean.getUserId())) {
							if (validation.validatedMobile(managerInfoBean.getMobileNumber()))   {
                                if(validation.validatedName(managerInfoBean.getUserName()))
	                                 return dao.managerRegistration(managerInfoBean);
                                 
								
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public boolean deleteManager(int id) {
		if(id!=0) {
			return dao.deleteManager(id);
		}
		return false;
	}

	@Override
	public boolean modifyManager(String emailId, long mobileNumber) {
		if (emailId != null && mobileNumber != 0) {
			if (validation.validatedEmail(emailId)) {
				if (validation.validatedMobile(mobileNumber)) {

					return dao.modifyManager(emailId, mobileNumber);
				}
			}
		}
		return false;
	}

	@Override
	public boolean insertCompany(CompanyInfoBean companyInfoBean) {
		if (companyInfoBean != null) {
			if (validation.validatedId(companyInfoBean.getCompanyId())) {
				if (validation.validatedName(companyInfoBean.getCompanyName())) {

				}

				return dao.insertCompany(companyInfoBean);
			}
		}
		return false;
	}

	@Override
	public boolean deleteCompany(String name) {
		if (name != null) {
			if(validation.validatedName(name)) {
				
			return dao.deleteCompany(name);
		} 
			}
		return false;
	}

	@Override
	public boolean modifyCompany(int id, String companyName) {
		if (id != 0 && companyName != null) {
			if (validation.validatedId(id)) {
				if (validation.validatedName(companyName)) {
					return dao.modifyCompany(id, companyName);
				}
			}
		}
		return false;
	}

	

	@Override
	public List<ManagerInfoBean> viewManagerDetails() {
		// TODO Auto-generated method stub
		return dao.viewManagerDetails();
	}

	@Override
	public AdminInfoBean authenticateAdmin(String email, String password) {
		if (validation.validatedEmail(email)) {
			if (validation.validatedPassword(password)) {
				return dao.authenticateAdmin(email, password);
			}

		}
		return null;
	}

	@Override
	public List<CompanyInfoBean> viewCompanyDetails() {
		// TODO Auto-generated method stub
		return dao.viewCompanyDetails();
	}

}

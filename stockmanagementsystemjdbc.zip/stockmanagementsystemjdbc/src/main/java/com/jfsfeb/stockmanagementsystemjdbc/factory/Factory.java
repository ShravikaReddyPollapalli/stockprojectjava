package com.jfsfeb.stockmanagementsystemjdbc.factory;

import com.jfsfeb.stockmanagementsystemjdbc.dao.AdminDAO;
import com.jfsfeb.stockmanagementsystemjdbc.dao.AdminDAOImpl;
import com.jfsfeb.stockmanagementsystemjdbc.dao.CompanyDAO;
import com.jfsfeb.stockmanagementsystemjdbc.dao.CompanyDAOImpl;
import com.jfsfeb.stockmanagementsystemjdbc.dao.InvestorDAO;
import com.jfsfeb.stockmanagementsystemjdbc.dao.InvestorDAOImpl;
import com.jfsfeb.stockmanagementsystemjdbc.service.AdminService;
import com.jfsfeb.stockmanagementsystemjdbc.service.AdminServiceImpl;
import com.jfsfeb.stockmanagementsystemjdbc.service.CompanyService;
import com.jfsfeb.stockmanagementsystemjdbc.service.CompanyServiceImpl;
import com.jfsfeb.stockmanagementsystemjdbc.service.InvestorService;
import com.jfsfeb.stockmanagementsystemjdbc.service.InvestorServiceImpl;
import com.jfsfeb.stockmanagementsystemjdbc.validation.Validation;
import com.jfsfeb.stockmanagementsystemjdbc.validation.ValidationImpl;

public class Factory {
	private Factory() {

	}

	public static AdminDAO getAdminDAOImplInstance() {
		AdminDAO dao = new AdminDAOImpl();
		return dao;
	}

	public static InvestorDAO getUserDAOImplInstance() {
		InvestorDAO userDao = new InvestorDAOImpl();
		return userDao;
	}

	public static CompanyDAO getCompanyDAOImplInstance() {
		CompanyDAO companyDao = new CompanyDAOImpl();
		return companyDao;
	}

	public static AdminService getAdminServiceImplInstance() {
		AdminService adminService = new AdminServiceImpl();
		return adminService;
	}

	public static CompanyService getCompanyServiceImplInstance() {
		CompanyService companyService = new CompanyServiceImpl();
		return companyService;
	}

	public static InvestorService getUserServiceImpl() {
		InvestorService userService = new InvestorServiceImpl();
		return userService;
	}
	
	public static Validation getValidationInstance() {
		Validation validation = new ValidationImpl();
		return validation;
	}
}

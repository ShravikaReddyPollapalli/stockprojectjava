package com.jfsfeb.stockmanagementsystemjdbc.service;

import java.util.List;


import com.jfsfeb.stockmanagementsystemjdbc.dao.InvestorDAO;
import com.jfsfeb.stockmanagementsystemjdbc.dto.BuyStockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.StockInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.UserInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.factory.Factory;
import com.jfsfeb.stockmanagementsystemjdbc.validation.Validation;

public class InvestorServiceImpl implements InvestorService {

	InvestorDAO dao = Factory.getUserDAOImplInstance();
	Validation validation = Factory.getValidationInstance();
	@Override
	public UserInfoBean userLogin(String emailId, String password) {
		if (emailId != null && password != null) {
			if (validation.validatedEmail(emailId)) {
				if (validation.validatedPassword(password)) {
					return dao.userLogin(emailId, password);
				}
			}
		}
		return null;
	}

	@Override
	public boolean modifyPassword(long mobileNumber, String password) {
		// TODO Auto-generated method stub
		return dao.modifyPassword(mobileNumber, password);
	}

	@Override
	public boolean userRegistration(UserInfoBean user) {
		if (user != null) {
			if (validation.validatedId(user.getUserId())) {
				if (validation.validatedName(user.getUserName())) {
					 
						if (validation.validatedEmail(user.getEmailId())) {
							if (validation.validatedPassword(user.getPassword())) {
								if (validation.validatedMobile(user.getMobileNumber())) {
								return dao.userRegistration(user);
							}
						}
					}
				}
			}
		}
		return false;
	}



	

	@Override
	public List<StockInfoBean> viewStockDetails() {
		// TODO Auto-generated method stub
		return dao.viewStockDetails();
	}

	@Override
	public BuyStockInfoBean showBuyStock(UserInfoBean userBean, StockInfoBean stockBean,
			BuyStockInfoBean buyStockBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean buyStock(UserInfoBean user, StockInfoBean stockBean) {
		if(user != null && stockBean != null) {
			if(validation.validatedId(stockBean.getId())) {
				if(validation.validatedId(user.getUserId())) {
					return dao.buyStock(user,stockBean);
				}
			}
		}
		return false;
	}

	
}

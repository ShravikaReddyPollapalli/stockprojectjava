package com.jfsfeb.stockmanagementsystemjdbc.dao;

import java.util.List;

import com.jfsfeb.stockmanagementsystemjdbc.dto.AdminInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.CompanyInfoBean;
import com.jfsfeb.stockmanagementsystemjdbc.dto.ManagerInfoBean;

public interface AdminDAO {
	boolean managerRegistration(ManagerInfoBean managerInfoBean);

	boolean modifyManager(String emailId, long mobileNumber);

	boolean deleteManager(int userId);

	List<ManagerInfoBean> viewManagerDetails();

	boolean insertCompany(CompanyInfoBean companyInfoBean);

	boolean modifyCompany(int userId, String companyName);

	boolean deleteCompany(String companyName);

	List<CompanyInfoBean> viewCompanyDetails();

	AdminInfoBean authenticateAdmin(String emailId, String password);
}
